import React from 'react'
import './style.css'


class Me extends React.Component {
    constructor(props) {
        super(props);
        // this.state = {
        //     micState: "off",
        //     webcamState: "on"
        // }
    }
    render() {
        let micState
        let webcamState
        if (this.props.isCameraOff) {
            webcamState = 'off';
        }else{
            webcamState = 'on';
        }
        if (this.props.isMicMuted) {
            micState = 'off';
        }else{
            micState = 'on';
        }
        
        return (
            <div data-component='Me'>
                <video id="localVideo" autoPlay muted playsInline></video>
                <div className="bottom-st-bar-me" >
                    <div className="st-bar" >
                        <div className='dp-name'>
                            <span>
                                {this.props.cont_name}
                            </span>
                        </div>
                        <div className='brand-shape'></div>
                        <div className='user-act' >
                            <button
                                className={[`dp-resp me-audio-${micState}`]}
                                disabled={true}
                            ></button>
                            <button
                                className={[`dp-resp me-video-${webcamState}`]}
                                disabled={true}
                            ></button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default Me;