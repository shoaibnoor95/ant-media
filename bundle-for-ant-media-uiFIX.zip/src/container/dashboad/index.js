import React from 'react'
import { WebRTCAdaptor } from "../../component/js/webrtc_adaptor.js"
import RightBar from '../right-bar'
import Me from '../../component/me'
// import Peers from '../../component/peers'
import './style.css'
import io from 'socket.io-client'

let player_div_style;
let player_video_style;
let player_bottom_style = "";
let player_bottom_style_shape = "";

export default class dashboard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            token: null,
            mute_mic_button: false,
            unmute_mic_button: false,
            streamId: null,
            webRTCAdaptor: null,
            playOnly: false,
            volume_change_input: null,
            roomName: 'room1',
            publishStreamId: null,
            isDataChannelOpen: false,
            isMicMuted: false,
            isCameraOff: false,
            roomTimerId: -1,
            pc_config: {
                'iceServers': [{
                    'urls': 'stun:stun1.l.google.com:19302'
                }]
            },
            sdpConstraints: {
                OfferToReceiveAudio: false,
                OfferToReceiveVideo: false

            },
            mediaConstraints: {
                video: true,
                audio: true
            },
            turn_on_camera_button: false,
            join_publish_button: false,
            appName: null,
            stop_publish_button: false,
            websocketURL: null,
            turn_off_camera_button: false,
            btn_p_chat: null,
            turnOnLocalCamera: false,
            roomTimerId: -1,
            p_chat: null,
            roomOfStream: [],
            streamsList: []
        }
        this.socket = io.connect();

    }


    componentDidMount() {
        this.initiateWebrtc();
        this.setState({
            isShow: true
        });
    }
    muteLocalMic = () => {
        this.state.webRTCAdaptor.muteLocalMic();
        this.setState({ isMicMuted: true });
        this.handleMicButtons();
        this.sendNotificationEvent("MIC_MUTED");
    }
    unmuteLocalMic = () => {
        this.state.webRTCAdaptor.unmuteLocalMic();
        this.setState({
            isMicMuted: false
        })
        this.handleMicButtons();
        this.sendNotificationEvent("MIC_UNMUTED");
    }
    initiateWebrtc() {
        let that = this
        this.state.webRTCAdaptor = new WebRTCAdaptor(
            {
                websocket_url: 'wss://demo.inquisitives.com:5443/WebRTCAppEE/websocket',
                mediaConstraints: this.state.mediaConstraints,
                peerconnection_config: this.state.pc_config,
                sdp_constraints: this.state.sdpConstraints,
                localVideoId: "localVideo",
                isPlayMode: false,
                debug: true,
                callback: function (info, obj) {
                    if (info == "initialized") {
                        console.log('initializeds')
                        that.setState({
                            join_publish_button: false,
                            stop_publish_button: true
                        })

                        //called by JavaScript SDK when WebSocket is connected. 
                    }
                    else if (info == "joinedTheRoom") {
                        //called when this client is joined the room
                        //obj contains streamId field which this client can use to publish to the room.
                        //obj contains also the active streams in the room so that you can play them directly.
                        //In order to get the streams in the room periodically call `getRoominfo`


                        const room = obj.ATTR_ROOM_NAME;
                        const roomOfStream = that.state.roomOfStream
                        roomOfStream[obj.streamId] = room;
                        that.setState({
                            publishStreamId: obj.streamId,
                            roomOfStream
                        })
                        //[obj.streamId] = room;
                        console.log("joined the room: " + roomOfStream[obj.streamId]);
                        // console.log(obj)
                        // that.setState({
                        // 
                        // })

                        if (that.state.playOnly) {
                            that.setState({
                                join_publish_button: true,
                                stop_publish_button: false,
                                isCameraOff: true

                            })
                            that.handleCameraButtons();
                        }
                        else {
                            that.publish(obj.streamId, that.state.token);
                        }

                        if (obj.streams != null) {
                            obj.streams.forEach(function (item) {
                                console.log("Stream joined with ID: " + item);
                                that.state.webRTCAdaptor.play(item, that.state.token,
                                    that.state.roomName);
                            });
                            that.setState({ streamsList: obj.streams });
                        }
                        that.setState({
                            roomTimerId: setInterval(() => {
                                that.state.webRTCAdaptor.getRoomInfo(that.state.roomName, that.state.publishStreamId);
                            }, 5000)
                        });
                        that.usersViewUpdate()

                    }
                    else if (info == "newStreamAvailable") {
                        //called when client is ready to play WebRTC stream.
                        that.playVideo(obj);
                        that.usersViewUpdate()
                    }
                    else if (info == "publish_started") {
                        that.setState({
                            join_publish_button: true,
                            stop_publish_button: false,
                        })

                        //called when stream publishing is started for this client		
                    }
                    else if (info == "publish_finished") {
                        //called when stream publishing has finished for this client
                        console.debug("publish finished");

                    }
                    else if (info == "leavedFromRoom") {
                        //called when this client is leaved from the room  	
                    }
                    else if (info == "screen_share_stopped") {
                        console.log("screen share stopped");
                    }
                    else if (info == "browser_screen_share_supported") {
                        // screen_share_checkbox.disabled = false;
                        // camera_checkbox.disabled = false;
                        // screen_share_with_camera_checkbox.disabled = false;
                        // console.log("browser screen share supported");
                        // browser_screen_share_doesnt_support.style.display = "none";
                    }
                    else if (info == "closed") {
                        //called when websocket connection is closed	
                    }
                    else if (info == "play_finished") {
                        //called when a stream has finished playing	
                    }
                    else if (info == "streamInformation") {
                        //called when a stream information is received from the server. 
                        //This is the response of `getStreamInfo` method
                        that.streamInformation(obj)
                    }
                    else if (info == "roomInformation") {
                        //Called by response of `getRoomInfo` when a room information is received from the server.
                        //It contains the array of the streams in the room.
                        for (let str of obj.streams) {
                            if (!that.state.streamsList.includes(str)) {
                                that.state.webRTCAdaptor.play(str, that.state.token,
                                    that.state.roomName);
                            }
                        }
                        // Checks if any stream has been removed, if yes, removes the view and stops webrtc connection.
                        for (let str of that.state.streamsList) {
                            if (!obj.streams.includes(str)) {
                                that.removeRemoteVideo(str);
                            }
                        }
                        //Lastly updates the current streamlist with the fetched one.
                        that.setState({

                            streamsList: obj.streams
                        })
                        
                    }
                    else if (info == "data_channel_opened") {
                        //called when data channel is opened
                        that.setState({ isDataChannelOpen: true });
                    }
                    else if (info == "data_channel_closed") {
                        // called when data channel is closed
                        that.setState({ isDataChannelOpen: false });

                    }
                    else if (info == "data_received") {
                        //called when data is received through data channel
                        that.handleNotificationEvent(obj)
                    }

                },
                callbackError: function (error, message) {
                    console.log(error, 'line', message)
                    //some of the possible errors, NotFoundError, SecurityError,PermissionDeniedError
                }
            });

    }
    // publish(streamName, token) {
    //    }
    switchVideoMode = (chbx) => {
        if (e.target.value == "screen") {
            this.state.webRTCAdaptor.switchDesktopCapture(this.state.publishStreamId);
        }
        else if (e.target.value == "screen+camera") {
            this.state.webRTCAdaptor.switchDesktopCaptureWithCamera(this.state.publishStreamId);
        }
        else {
            this.state.webRTCAdaptor.switchVideoCameraCapture(this.state.publishStreamId, chbx.value);
        }
    }
    switchVideoMode(mode) {
        if (mode == "screen") {
            this.state.webRTCAdaptor.switchDesktopCapture(publishStreamId);
        }
        else if (mode == "screen+camera") {
            this.state.webRTCAdaptor.switchDesktopCaptureWithCamera(publishStreamId);
        }
        else {
            this.state.webRTCAdaptor.switchVideoCameraCapture(publishStreamId, mode);
        }
    }
    turnOffLocalCamera = () => {
        this.state.webRTCAdaptor.turnOffLocalCamera();
        this.setState({
            isCameraOff: true
        })
        this.handleCameraButtons();
        this.sendNotificationEvent("CAM_TURNED_OFF");
    }

    turnOnLocalCamera = () => {
        this.state.webRTCAdaptor.turnOnLocalCamera();
        this.setState({
            isCameraOff: false
        })
        this.handleCameraButtons();
        this.sendNotificationEvent("CAM_TURNED_ON");
    }
    handleCameraButtons = () => {
        if (this.state.isCameraOff) {
            this.setState({
                turn_off_camera_button: true,
                turn_on_camera_button: false
            })
        } else {
            this.setState({
                turn_off_camera_button: false,
                turn_on_camera_button: true
            })
        }
    }
    joinRoom = () => {

        this.state.webRTCAdaptor.joinRoom(this.state.roomName, this.state.streamId);
    }
    leaveRoom = () => {
        this.state.webRTCAdaptor.leaveFromRoom(this.state.roomName);
        let availableNodes = document.getElementById("players").childNodes
        for (var node in availableNodes) {
            if (node.tagName == 'DIV' && node.id != "localVideo") {
                document.getElementById("players").removeChild(availableNodes[node]);
            }
        }
        this.usersViewUpdate()
    }
    publish = (streamName, token) => {
        this.setState({
            publishStreamId: streamName
        })
        this.state.webRTCAdaptor.publish(streamName, token);
    }
    streamInformation = (obj) => {
        this.state.webRTCAdaptor.play(obj.streamId, this.state.token, this.state.roomName);
    }
    playVideo = (obj) => {
        let room = this.state.roomOfStream[obj.streamId];
        console.log("new stream available with id: " + obj.streamId + "on the room:" + room);

        let video = document.getElementById("remoteVideo" + obj.streamId);

        if (video == null) {
            this.createRemoteVideo(obj.streamId);
            video = document.getElementById("remoteVideo" + obj.streamId);
        }

        video.srcObject = obj.stream;
    }
    sendNotificationEvent = (eventType) => {
        if (this.state.isDataChannelOpen) {
            const notEvent = { streamId: this.state.streamId, eventType: eventType };
            this.state.webRTCAdaptor.sendData(this.state.publishStreamId, JSON.stringify(notEvent));
        } else {
            console.log("Could not send the notification because data channel is not open.");
        }
    }
    usersViewUpdate = () => {
        if (this.state.streamsList.length === 1) {
            player_div_style = "player-canvs";
            player_video_style = "player-video-canvs";
        }
        if (this.state.streamsList.length > 1 && this.state.streamsList.length <= 2) {
            player_div_style = "player-canvs-102";
            player_video_style = "player-video-canvs-102";
        }
        if (this.state.streamsList.length > 2 && this.state.streamsList.length <= 4) {
            player_div_style = "player-canvs-103";
            player_video_style = "player-video-canvs-103";
        }
        if (this.state.streamsList.length > 4 && this.state.streamsList.length <= 12) {
            player_div_style = "player-canvs-104";
            player_video_style = "player-video-canvs-104";
            player_bottom_style = "player-bottom-bar-104";
            player_bottom_style_shape = "player-bar-shape-104"
        } else {
            player_bottom_style = "";
            player_bottom_style_shape = ""
        }
    }
    createRemoteVideo = (streamId) => {
        this.usersViewUpdate()
        // main div can control players
        var player = document.getElementById("players");
        //  div can control player
        let player_div = document.createElement("div");
        player_div.className = player_div_style;
        player_div.id = "player" + streamId;
        //  div can control player video
        let player_video_div = document.createElement("div");
        player_video_div.className = player_video_style;
        player_video_div.innerHTML = '<video id="remoteVideo' + streamId + '" autoPlay playsInline></video>';
        //  div can control player bar
        let player_bottom_bar = document.createElement("div");
        player_bottom_bar.className = 'player-bottom-bar ' + player_bottom_style;
        //  div can control player  name
        let player_bottom_bar_user_name = document.createElement("div");
        player_bottom_bar_user_name.className = "player-dp-name"
        //  div can control player name value
        let player_name = document.createElement('span');
        player_name.innerText = streamId;
        player_bottom_bar_user_name.appendChild(player_name)
        //  div can control bar shape
        let player_bottom_bar_shape = document.createElement("div");
        player_bottom_bar_shape.className = "player-bar-shape " + player_bottom_style_shape;
        //  div can control bar extra feautres
        let player_bottom_bar_content = document.createElement("div");
        player_bottom_bar_content.className = "player-user-act"

        player_bottom_bar.appendChild(player_bottom_bar_user_name)
        player_bottom_bar.appendChild(player_bottom_bar_shape)
        player_bottom_bar.appendChild(player_bottom_bar_content)
        player_div.appendChild(player_video_div);
        player_div.appendChild(player_bottom_bar);
        player.appendChild(player_div);
    }


    removeRemoteVideo = (streamId) => {
        var video = document.getElementById("remoteVideo" + streamId);
        if (video != null) {
            var player = document.getElementById("player" + streamId);
            video.srcObject = null;
            document.getElementById("players").removeChild(player);
        }
        this.state.webRTCAdaptor.stop(streamId);
    }
    // startAnimation = () => {

    //     $("#broadcastingInfo")
    //         .fadeIn(
    //             800,
    //              ()=> {
    //                 $("#broadcastingInfo")
    //                     .fadeOut(
    //                         800,
    //                         function () {
    //                             var state =this.state.
    //                                 .signallingState(publishStreamId);
    //                             if (state != null
    //                                 && state != "closed") {
    //                                 var iceState = webRTCAdaptor
    //                                     .iceConnectionState(publishStreamId);
    //                                 if (iceState != null
    //                                     && iceState != "failed"
    //                                     && iceState != "disconnected") {
    //                                    that.startAnimation();
    //                                 }
    //                             }
    //                         });
    //             });

    // }
    handleNotificationEvent = (obj) => {
        console.log("Received data : ", obj.event.data);
        var notificationEvent = JSON.parse(obj.event.data);
        if (notificationEvent != null && typeof (notificationEvent) == "object") {
            var eventStreamId = notificationEvent.streamId;
            var eventTyp = notificationEvent.eventType;

            if (eventTyp == "CAM_TURNED_OFF") {
                console.log("Camera turned off for : ", eventStreamId);
            } else if (eventTyp == "CAM_TURNED_ON") {
                console.log("Camera turned on for : ", eventStreamId);
            } else if (eventTyp == "MIC_MUTED") {
                console.log("Microphone muted for : ", eventStreamId);
            } else if (eventTyp == "MIC_UNMUTED") {
                console.log("Microphone unmuted for : ", eventStreamId);
            }
        }
    }

    handleMicButtons = () => {
        if (this.state.isMicMuted) {
            this.setState({
                mute_mic_button: true,
                unmute_mic_button: false
            })
        } else {
            this.setState({
                mute_mic_button: false,
                unmute_mic_button: true
            })
        }
    }
    componentWillUnmount() {
        // this.props.socket.emit('leaveRoom', this.props.room)
        sessionStorage.clear()
    }
    render() {

        let canvas_players
        let canvas = "align"
        if (this.state.streamsList.length === 1) {
            canvas_players = "canvas_players"
        }
        if (this.state.streamsList.length > 1 && this.state.streamsList.length <= 2) {
            canvas = "align"
            canvas_players = "canvas_players-102"
        }
        if (this.state.streamsList.length > 2 && this.state.streamsList.length <= 4) {
            canvas = "align-103"
            canvas_players = "canvas_players-103"
        }
        if (this.state.streamsList.length > 4 && this.state.streamsList.length <= 12) {
            canvas = "align-104"
            canvas_players = "canvas_players-104"
        }

        return (
            <div data-component='Room'>
                <div className={`video-canvas ${canvas}`}>
                    {/* <div className={brand_me_container}>
                        <div className={me_cont_brnd}>
                            <Me
                                isCameraOff={this.state.isCameraOff}
                                isMicMuted={this.state.isMicMuted}
                                cont_name={"user Name"}
                            />
                        </div>
                    </div> */}
                    {/* {this.state.streamsList.length > 0 ? (
                        // <div className={brand_pears_container} id="players">
                        // </div>

                        <div style={{
                            width: "100%",
                            height: "calc(100vh)",
                            border: "1px solid red"
                        }}>

                        </div>
                    ) : null} */}
                    <div className={canvas_players} id="players"></div>
                </div>

                <RightBar
                    isCameraOff={this.state.isCameraOff}
                    meCameraOff={this.turnOffLocalCamera}
                    meCameraOn={this.turnOnLocalCamera}
                    isMicMuted={this.state.isMicMuted}
                    meMicOff={this.muteLocalMic}
                    meMicOn={this.unmuteLocalMic}
                    room={this.state.roomName}
                    socket={this.socket}
                    cont_name={"user Name"}
                    users={this.state.streamsList}
                />

                {/* <div style={{ width: "calc(95vw)" }} > */}
                {/* <div className="col-md-4" style={{ height: 'calc(100vh - 7vh)', overflow: 'hidden', }}>
                        <video style={{ width: '100%', height: '100%' }} id="localVideo" autoPlay muted playsInline></video>
                    </div> */}
                {/*<div className="col-md-8" style={{ height: 'calc(100vh - 7vh)', overflowY: 'scroll' }}>
                        <div className={cont_box} id="players">
                        </div>
                    </div> */}
                {/* </div> */}
                <div style={{ top: '0px', backgroundColor: 'rgba(0,0,0,0.1)', width: "30%", position: 'absolute', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                    <button className="btn btn-info"
                        id="join_publish_button" onClick={this.joinRoom} disabled={this.state.join_publish_button}>Join Room</button>
                    <button className="btn btn-info" onClick={this.leaveRoom} disabled={this.state.stop_publish_button}
                        id="stop_publish_button">Leave Room</button>
                </div>
                {/* <div className="container"> */}


                {/* <div className="jumbotron"> */}
                {/* <div id="players">
                            <div className="col-sm-3">
                                <video id="localVideo" autoPlay muted controls playsInline></video>
                            </div>
                        </div> */}



                {/* <div className="row">
                            <div className="col-sm-6 col-sm-offset-3">
                                <p>
                                    <input type="text" className="form-control" value="room1" onChange={(e) => { this.setState({ roomName: e.target.value }) }}
                                        id="roomName" placeholder="Type room name" />
                                </p>
                                <p> */}

                {/* </p>

                                <div style={{ padding: '10px' }}>
                                    <button id="turn_off_camera_button" disabled={this.state.turn_off_camera_button} className="btn btn-default" onClick={this.turnOffLocalCamera}  >Turn off Camera</button>
                                    <button id="turn_on_camera_button" disabled={this.state.turn_on_camera_button} onClick={this.turnOnLocalCamera} className="btn btn-default"  >Turn on Camera</button>

                                    <button id="mute_mic_button" className="btn btn-default" onClick={this.muteLocalMic}  >Mute Local Mic</button>
                                    <button id="unmute_mic_button" disabled={this.state.unmute_mic_button} onClick={this.unmuteLocalMic} className="btn btn-default"  >Unmute Local Mic</button>
                                </div>

                                <div className="form-check form-check-inline" >

                                    <input className="form-check-input video-source" disabled name="videoSource" type="radio" value="camera"
                                        id="camera_checkbox" checked />
                                    <label className="form-check-label" for="camera_checkbox" style={{ fontWeight: 'normal' }}>
                                        Camera
                            </label>

                                    <input className="form-check-input video-source" disabled name="videoSource" type="radio" value="screen"
                                        id="screen_share_checkbox" />
                                    <label className="form-check-label" for="screen_share_checkbox" style={{ fontWeight: 'normal' }}>
                                        Screen
                            </label>


                                    <input className="form-check-input video-source" disabled name="videoSource" type="radio" value="screen+camera"
                                        id="screen_share_with_camera_checkbox" />
                                    <label className="form-check-label" for="screen_share_with_camera_checkbox" style={{ fontWeight: 'normal' }}>
                                        Screen with Camera
                            </label>
                                    <div className="form-check form-check-inline"></div>
                                    <a id="browser_screen_share_doesnt_support" href="https://caniuse.com/#search=getDisplayMedia">Your browser doesn't support screen share. You can see supported browsers in this link </a>
                                </div>
                                <span className="label label-success" id="broadcastingInfo"
                                    style={{ fontSize: '14px', display: 'none' }}>Publishing</span>
                            </div>
                        </div>*/}


                {/* </div> */}
                {/* <footer className="footer">
                        <p>
                            <a href="http://antmedia.io">Ant Media Server Enterprise
                        Edition</a>
                        </p>
                    </footer>  */}

                {/* </div> */}
                {/* <div style={{  width: "calc(5vw)",}}> */}
                {/* </div> */}
            </div>
        )
    }
}