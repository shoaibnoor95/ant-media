// import MicEnable from "../../assets/icons/icons-actions-mic-enable.svg";
// import VideoEnable from "../../assets/icons/icons-actions-video-enable.svg";
// import GroupUsers from "../../assets/icons/icons-actions-users-inactive.svg";
// import PublicMessage from "../../assets/icons/icons-actions-chat-fill-inactive.svg";
// import PolliFill from "../../assets/icons/icons-actions-poll-fill-inactive.svg";
// import Notes from "../../assets/icons/icons-actions-notes-inactive.svg";
// import WhiteBoard from "../../assets/icons/icons-actions-whiteboard-inactive.svg";
// import ScreenShare from "../../assets/icons/icons-actions-share-fill-inactive.svg";
// import Layout from "../../assets/icons/icons-actions-change-layout-inactive.svg";
// import Settings from "../../assets/icons/icons-actions-settings-fill-inactive.svg";
// import Exit from "../../assets/icons/icons-actions-exit-inactive.svg";
import PublicChatBoat from '../../component/public-chat'
import WhiteBoardComponent from '../../component/white-board'
import NotesForPublic from '../../component/notes'
import PollingComponent from '../../component/polling'
import React from 'react'
import { connect } from 'react-redux';
import Users from '../../component/users'
import './style.css'

class RightBar extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            micState: "on",
            webcamState: "on",
            grid: "off",
            users: true,
            public_chat: false,
            notes: false,
            polling: false,
            shareState: 'off',
            whiteboard: false,
        }
    }
    render() {
        return (
            <div className='sidebar' >
                <div className="empty-box"></div>
                <div className='me-action'>
                    {this.props.isMicMuted ? (
                        <button onClick={this.props.meMicOn} className="me-btn" data-title="Mic">
                            <img src={'/assets/icons/icons-actions-mic-disable.svg'} alt="mic" />
                        </button>
                    ) : (
                        <button onClick={this.props.meMicOff} className="me-btn" data-title="Mic">
                            <img src={'/assets/icons/icons-actions-mic-enable.svg'} alt="mic" />
                        </button>
                    )}
                    {this.props.isCameraOff ? (
                        <button onClick={this.props.meCameraOn} className="me-btn" data-title="Video">
                            <img src={'/assets/icons/icons-actions-video-disable.svg'} alt="video" />
                        </button>
                    ) : (
                        <button onClick={this.props.meCameraOff} className="me-btn" data-title="Video">
                            <img src={'/assets/icons/icons-actions-video-enable.svg'} alt="video" />
                        </button>
                    )}
                </div>
                <div className="brand-options">
                    {/* <button className={`me-opt-grid grid ${this.state.grid}`}
                        onClick={() => {

                        }}
                    ></button> */}
                    <button className={`me-opt-users users-${this.state.users}`}
                        onClick={() => {
                            this.setState({
                                // users: !this.state.users,
                                public_chat: false,
                                notes: false,
                                polling: false,
                                whiteboard: false,
                                shareScreen: false,
                            })
                        }}
                    ></button>
                    <button className={`me-opt-chat chat-${this.state.public_chat}`}
                        onClick={() => {
                            this.setState({
                                public_chat: !this.state.public_chat,
                                // users: false,
                                polling: false,
                                notes: false,
                                whiteboard: false,
                                shareScreen: false,
                            })
                        }}
                    ></button>
                    <button className={`me-opt-notes notes-${this.state.notes}`}
                        onClick={() => {
                            this.setState({
                                notes: !this.state.notes,
                                // users: false,
                                public_chat: false,
                                polling: false,
                                shareScreen: false,
                                whiteboard: false
                            })
                        }}
                    ></button>
                    <button className={`me-opt-poll poll-${this.state.polling}`}
                        onClick={() => {
                            this.setState({
                                polling: !this.state.polling,
                                // users: false,
                                public_chat: false,
                                notes: false,
                                whiteboard: false,
                                shareScreen: false,
                            })
                        }}
                    ></button>
                    <button
                        className={`me-opt-shareScreen shareScreen-${this.state.shareState}`}
                        onClick={() => {
                            // if (shareState === 'on')
                            //     roomClient.disableShare();
                            // else
                            //     roomClient.enableShare();
                        }}
                    ></button>
                    <button
                        className={`me-opt-whiteboard whiteboard-${this.state.whiteboard}`}
                        onClick={() => {
                            this.setState({
                                whiteboard: !this.state.whiteboard,
                                public_chat: false,
                                // users: false,
                                polling: false,
                                shareScreen: false,
                                notes: false,
                            })
                        }}
                    ></button>
                </div>

                {
                    this.state.users ? (
                        <Users 
                            localData={this.props.cont_name} 
                            room={this.props.room} 
                            socket={this.props.socket} 
                            users={this.props.users}
                            isCameraOff={this.props.isCameraOff}
                            isMicMuted={this.props.isMicMuted}
                        />
                    ) : null
                }
                {
                    this.state.public_chat ? (
                        <PublicChatBoat room={this.props.room} socket={this.props.socket} />
                    ) : null
                }
                {
                    this.state.whiteboard ? (
                        <WhiteBoardComponent room={this.props.room} socket={this.props.socket} />
                    ) : null
                }
                {
                    this.state.notes ? (
                        <NotesForPublic room={this.props.room} socket={this.props.socket} />
                    ) : null
                }
                {
                    this.state.polling ? (
                        <PollingComponent room={this.props.room} socket={this.props.socket} />
                    ) : null
                }
            </div >
        )
    }
}
const mapStateToProps = () => {
    return {}
}

export default connect(mapStateToProps, null)(RightBar)