import paper from 'paper';

window.onload = function () {
    paper.install(window);
    let canvas = document.getElementById("wihite_board")
    paper.setup(canvas);

    var myPath = new paper.Path();
    myPath.strokeColor = 'red';
    myPath.add(new paper.Point(0, 0));
    myPath.add(new paper.Point(100, 50));
    // draw or call your drawing functions here

}
