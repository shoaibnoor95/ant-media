import {
    publicMessageDispatch
} from '../middle'

export const publicMessageStore = (data, room)=>{
    return dispatch =>{
        let array = [];
        array.push(data)
        sessionStorage.setItem(room, JSON.stringify(array))
        dispatch(publicMessageDispatch(data))
    }
}