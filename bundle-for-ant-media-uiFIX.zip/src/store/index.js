import { createStore, combineReducers, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';

import PoolingRed from './reducers/pooling_reducers'
import Messages from './reducers/message'

export default createStore(
    combineReducers({
        PoolingRed,
        Messages
    }),
    {},
    applyMiddleware(thunk)
);