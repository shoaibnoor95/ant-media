import actionTypes from '../middle/actionTypes';

const Messages = (state = {
    Message_Data: [],
}, action) => {
    switch (action.type) {
        case actionTypes.PUBLIC_MESSAGES: {
            return state = {
                ...state,
                Message_Data: action.payload
            }
        }
        default: { }
    }
    return state;
}
export default Messages;