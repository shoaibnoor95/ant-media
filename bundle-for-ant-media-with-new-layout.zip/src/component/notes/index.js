import React, { useState } from 'react'
import './style.css'
import Paper from 'paper';
// import Profile from '../../assets/img/adjust-tie.jpeg'


let activeText, that;
let textLayerMultiLine, noteText, previousSelected
class NotesForPublic extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            addFlag: false,
            listOfLayers: [],
            listOfText: [],
            textX: 10,
            textY: 20,
            todoArray: [],
            text: "",
            lineCount: 1
        }
        that = this
    }
    componentDidMount() {
        // adding paper.js / adding canvas
        Paper.install(window);
        const canvas = document.getElementById("notes_board");
        Paper.setup(canvas);

        // adding background layer
        var url = 'https://i.pinimg.com/originals/1c/cd/aa/1ccdaaab931962febc8644df28084afb.jpg';
        // adding background layer
        let raster = new Paper.Raster(url);
        // adding layers for multi task
        textLayerMultiLine = new Paper.Layer();
        textLayerMultiLine.activate()
    }
    addNewText() {
        let x = this.state.textX
        let y = this.state.textY * this.state.lineCount
        let layer = new Paper.Layer()

        this.setState({
            listOfLayers: this.state.listOfLayers.concat(layer)
        }, () => {
            this.state.listOfLayers[this.state.listOfLayers.length - 1].activate()
        })

        if (activeText) {
            activeText.selected = false
        }
        let text = new Paper.PointText({
            point: [x, y],
            content: "- " + " " + this.state.text,
            fillColor: 'black',
            fontFamily: 'arial',
            fontSize: 16,
            group: {
                name: this.state.lineCount
            },
            selected: true
        });

        this.setState({
            listOfText: this.state.listOfText.concat(text)
        }, () => {
            activeText = this.state.listOfText[this.state.listOfText.length - 1]
        })

        let keys = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
        let line = paper.project.view.bounds.width / 9;
        this.state.lineCount += 1
        this.setState({
            lineCount: this.state.lineCount,
        })
        Paper.view.onKeyDown = (event) => {
            let keyPress = keys.find((e) => e === event.key)
            if (event.key === keyPress) {
                activeText.content += keyPress
                if (activeText.content.length > line) {
                    activeText.content += '\n'
                    line = line + paper.project.view.bounds.width / 9
                    this.state.lineCount += 1
                    this.setState({
                        lineCount: this.state.lineCount,
                    })
                }
                previousSelected = activeText
            }
            activeText.onMouseDown = (e) => {
                if (previousSelected) {
                    previousSelected.selected = false
                } else {
                    activeText.selected = false
                }
                e.target.selected = true
                activeText = e.target
                previousSelected = activeText
            }

        }

        window.addEventListener("keydown", this.keyboardSpecialButtons)
    }
    keyboardSpecialButtons(e) {
        if (e.keyCode === 32) {
            let a = activeText.content += ' '
            activeText.content = a.replace(/  +/g, ' ');
            e.preventDefault()
            return false
        }
        if (e.keyCode === 8 || e.keyCode === 46) {
            let del = [...activeText.content]
            let edited = del.slice(0, del.length - 1).toString().replace(/,/g, '')
            activeText.content = String(edited);
            for (var key in previousSelected._lines) {
                if (previousSelected._lines[key].length < 1 && previousSelected._lines.length > 1) {
                    that.setState({
                        lineCount: that.state.lineCount -= 1
                    })
                }
            }
            e.preventDefault()
            return false
        }
    }
    componentWillUnmount() {
        window.removeEventListener("keydown", this.keyboardSpecialButtons)

        return false
    }
    boldText() {
        if (activeText) {
            let bold = activeText.fontWeight
            if (bold === "normal") {
                activeText.fontWeight = "bold"
            } else {
                activeText.fontWeight = "normal"
            }
        }
    }
    // italicText() {
    //     if (activeText) {
    //         // let italic = activeText.style
    //         // console.log(italic.fontStyle)
    //         // if (italic === "normal 16px arial") {
    //         //     activeText.fontStyle = "italic 16px arial"
    //         // } else {
    //         //     activeText.fontStyle = "normal 16px arial"
    //         // }
    //     }
    // }
    // underlineText() {
    //     if (activeText) {
    //         // let underline = activeText.style
    //         // console.log(activeText.textDecoration,"/////")
    //         // console.log(underline)
    //         // if (underline === "normal") {
    //         //     activeText.fontWeight = "bold"
    //         // } else {
    //         //     activeText.fontWeight = "normal"
    //         // }
    //     }
    // }
    download(el) {
        let canvas_raster = new Paper.Raster();
        canvas_raster.crossOrigin = "anonymous"
        let canvasD = document.getElementById("notes_board");
        canvas_raster.setImage(canvasD);
        let rect_area_pos = new Paper.Rectangle(0, 0, 270, 500);
        let sub_can_area = canvas_raster.getSubRaster(rect_area_pos);
        let dataUrl = sub_can_area.toDataURL("image/png", 1.0).replace("image/png", "image/octet-stream");
        var link = document.createElement('a');
        link.download = "my-image.png";
        link.href = dataUrl;
        link.click();
    }
    clear() {
        Paper.project.clear()
        this.setState({
            lineCount: 1,
            listOfLayers: [],
            listOfText: []
        })
    }
    render() {
        return (
            <div className="notes-box">
                <div className="user-info">
                    <div className="user-n">
                        <div className="wb-message" style={{ width: "12em" }}>
                            <span style={{ fontSize: "1.15em" }}>My Name</span>
                        </div>
                        <div className="wb-shape-nt"></div>
                    </div>
                    <div className="user-p">
                        <img src={'/assets/img/adjust-tie.jpeg'} alt="profile" />
                    </div>
                </div>
                <div className="notes-tb">
                    <div className="note-hh">
                        <div className="wb-message" style={{ width: "5em" }}>
                            <span style={{ fontSize: "1.15em" }}>Notes</span>
                        </div>
                        <div className="wb-shape-nt"></div>
                    </div>
                    <div className="note-tt">
                        <button data-title-down="Bold" onClick={this.boldText.bind(this)} className="bold">
                            <span className="glyphicon glyphicon-bold"></span>
                        </button>
                        {/* <button data-title-down="Italic" onClick={this.italicText.bind(this)} className="italic">I</button>
                        <button data-title-down="Underline" onClick={this.underlineText.bind(this)} className="undeler">U</button>
                        <button data-title-down="Delete"><s>S</s></button> */}
                        <button data-title-down="New Line" className="add" onClick={this.addNewText.bind(this)}>
                            <span className="glyphicon glyphicon-plus"></span>
                        </button>
                        <button data-title-down="All Clear" className="add" onClick={this.clear.bind(this)}>
                            <span className="glyphicon glyphicon-refresh"></span>
                        </button>
                        <button data-title-down="Download" className="add" onClick={this.download.bind(this)}>
                            <span className="glyphicon glyphicon-download-alt"></span>
                        </button>
                    </div>
                    <div className="note-dd">
                        <canvas id="notes_board" className="noteCanv"></canvas>
                    </div>
                </div>
                {/* {this.state.addFlag ? (
                    <div class="modal">
                        <div class="modal-content">
                            <div className="model-header">
                                <div className="model-header-l">
                                    <span>
                                        Add Notes...
                                </span>
                                </div>
                                <div className="model-header-r">
                                    <span onClick={() => {
                                        this.setState({
                                            addFlag: false
                                        })
                                    }} class="close">&times;</span>
                                </div>
                            </div>
                            <div className="model-dd">
                                <div className="midle">
                                    <textarea onChange={(e) => this.setState({ text: e.target.value })} type="text" placeholder="type..." />
                                </div>
                                <div className="btm">
                                    <button onClick={() => this.addNewText()}>Add</button>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : null} */}
            </div>
        )
    }
}



export default NotesForPublic