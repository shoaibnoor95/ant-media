import React from 'react';
import { connect } from 'react-redux';
import './style.css'
// import SentBTN from '/assets/icons/send-button.svg'
import { publicMessageStore } from '../../store/actions/messages'


class PublicChatBoat extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            message: "",
            publicMessage: []
        }
    }
    
    componentDidMount() {
        this.props.socket.emit('joinRoom', this.props.room)
        this.props.socket.on('receiveMessage', (message) => {
            this.setState({ publicMessage: this.state.publicMessage.concat(message.obj) })
        })
        let key = sessionStorage.getItem(this.props.room)
        if(JSON.parse(key) !== null && JSON.parse(key).length > 0){
            let array = JSON.parse(key)

            for(var keys in array){
                this.setState({ publicMessage: this.state.publicMessage.concat(array[keys]) })
            }
        }
    }
    componentWillUnmount() {
        // this.props.socket.emit('leaveRoom', this.props.room)
    }
    sentMessage() {
        const mess = this.state.message
        if (mess !== "" && mess !== " ") {
            let obj = {
                message: mess,
                time: new Date(),
                userID: "123",
                userName: "testing",
                me: true
            }
            this.setState({
                publicMessage: this.state.publicMessage.concat(obj),
                message: ""
            }, () => {
                this.props.publicMessageStore(
                    this.state.publicMessage,
                    this.props.room
                )
            })

            let body = {
                obj: {
                    message: mess,
                    time: new Date(),
                    userID: "123",
                    userName: "testing",
                    me: false
                }, room: this.props.room
            }
            this.props.socket.emit('sendMessage', body)

        } else {
            console.log("empty message")
        }
    }
    render() {
        let PublicMessageData;
        if (this.state.publicMessage.length > 0) {
            const messages = this.state.publicMessage;
            PublicMessageData = messages.map((v, i) => {
                console.log(v.me)
                return (
                    <div key={i}>
                        {v.me ? (
                            <div className="message-item" >
                                <div className="message-light-box-me tri-left right-top">
                                    <div className="message">
                                        <p style={{ color: "#fff" }}>{v.message}</p>
                                    </div>
                                </div>
                                <div className="profile" user-title={v.userName}>
                                    <div className="avt"></div>
                                </div>
                            </div>
                        ) : (
                            <div className="message-item" >
                                <div className="profile" user-title={v.userName}>
                                    <div className="avt"></div>
                                </div>
                                <div className="message-light-box tri-right left-top">
                                    <div className="message">
                                        <p>{v.message}</p>
                                    </div>
                                    {/* <div className="sent-time">
                                <span>{v.time.getHours()}:{v.time.getMinutes()}:{v.time.getSeconds()}</span>
                            </div> */}
                                </div>
                            </div >
                        )}
                    </div >
                )
            })
        }
        return (
            <div className="public-chat">
                <div className="heding-p">
                    <div className="wb-message" style={{ width: "8em" }}>
                        <span>Public Chat</span>
                    </div>
                    <div className="wb-shape-ch"></div>
                </div>
                <div className="users-chatings">
                    {PublicMessageData}
                </div>
                <div className="chat-input">
                    <div className="inputs">
                        <input value={this.state.message} onChange={(text) => this.setState({ message: text.target.value })} type="text" placeholder="Abc There..." />
                    </div>
                    <div className="sent-box">
                        <button onClick={this.sentMessage.bind(this)} className="sent">
                            <img src={'/assets/icons/send-button.svg'} alt="SentBTN" />
                        </button>
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    console.log(state)
    return {
        messages: state.Messages.Message_Data
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        publicMessageStore: (data, room) => {
            dispatch(publicMessageStore(data, room))
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(PublicChatBoat)