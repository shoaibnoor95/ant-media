import React from "react"
import './style.css'
// import Options from '../../assets/icons/icons-actions-overflow.svg'

class VeziuHeader extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            room: "connected",
            peers: []
        }
    }
    render() {
        return (
            <div className='brand-header'>
                <div className='brand-logo'></div>
                <div className='meeting-span'>
                    <span>{"My meeting title"}</span>
                </div>
                <div className='brand-shape'></div>
                <div className='brand-dp'>
                    <div className="meet-time">
                        <div className="time">
                            <span>{"60"}</span>
                        </div>
                        <div className="col">
                            <span>:</span>
                        </div>
                        <div className="time">
                            <span>{"60"}</span>
                        </div>
                        <div className="col">
                            <span>:</span>
                        </div>
                        <div className="time">
                            <span>{"60"}</span>
                        </div>
                    </div>
                    <div className="active-state">
                        <div className='online-indicator' />
                        <div className="online-mess">
                            <span>{this.state.room === 'connected' ? "LIVE EVENT" : this.state.room}</span>
                        </div>
                    </div>
                    <div className="active-users">
                        <div className="user-q">
                            <span>{this.props.users.length > 0 ? this.props.users.length + 1 : '0'}</span>
                        </div>
                        <div className="col">
                            <span>:</span>
                        </div>
                        <div className="att-mess">
                            <span>ATTENDEES</span>
                        </div>
                    </div>
                </div>
                <div className="res"></div>
            </div>
        )
    }
}

export default VeziuHeader;