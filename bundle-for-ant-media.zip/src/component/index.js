import { Router, Switch, Route } from "react-router-dom"
import history from '../history'

// ============== component/container=====================
import VeziuHeader from '../container/header'
import Dashboard from '../container/dashboad'
import React from 'react'
export default function VezuRouter() {
    return (
        <Router history={history}>
            <div style={{backgroundColor: "#fff"}}>
                {/* ********header**************************** */}
                <VeziuHeader />
                {/* **************control components********** */}
                <Switch>
                    <Route exact path="/">
                        <Dashboard/>
                    </Route>
                </Switch>
            </div>
        </Router>
    )
}