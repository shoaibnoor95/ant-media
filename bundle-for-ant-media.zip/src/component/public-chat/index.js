import React from 'react';
import './style.css'
// import SentBTN from '/assets/icons/send-button.svg'

class PublicChatBoat extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            message: "",
            publicMessage: []
        }
    }
    componentDidMount(){
        this.props.socket.emit('joinRoom',this.props.room)
        this.props.socket.on('receiveMessage',(message)=>{
            alert(message)
        })
    }
    componentWillUnmount(){
        this.props.socket.emit('leaveRoom',this.props.room)
    }
    sentMessage() {
        const mess = this.state.message

        if (mess !== "" && mess !== " ") {
            let obj = {
                message: mess,
                time: new Date(),
                userID: "123",
                userName: "testing",
            } 
            let body={obj,room:this.props.room}
            this.props.socket.emit('sendMessage',body)
            this.setState({
                publicMessage: this.state.publicMessage.concat(obj),
                message: ""
            })
        } else {
            console.log("empty message")
        }
    }
    render() {
        let PublicMessageData;
        if (this.state.publicMessage.length > 0) {
            const messages = this.state.publicMessage;
            PublicMessageData = messages.map((v, i) => {
                return (
                    <div className="message-item" key={i}>
                        <div className="profile" user-title={v.userName}></div>
                        <div className="message-light-box tri-right left-top">
                            <div className="message">
                                <p>{v.message}</p>
                            </div>
                            {/* <div className="sent-time">
                                <span>{v.time.getHours()}:{v.time.getMinutes()}:{v.time.getSeconds()}</span>
                            </div> */}
                        </div>

                    </div>
                )
            })
        }
        return (
            <div className="public-chat">
                <div className="heding-p">
                    <div className="wb-message" style={{width: "8em"}}>
                        <span>Public Chat</span>
                    </div>
                    <div className="wb-shape-ch"></div>
                </div>
                <div className="users-chatings">
                    {PublicMessageData}
                </div>
                <div className="chat-input-box">
                    <div className="input">
                        <input value={this.state.message} onChange={(text) => this.setState({ message: text.target.value })} type="text" placeholder="Abc There..." />
                    </div>
                    <div className="sent-box">
                        <button onClick={this.sentMessage.bind(this)} className="sent">
                            <img src={'/assets/icons/send-button.svg'} alt="SentBTN" />
                        </button>
                    </div>
                </div>
            </div>
        )
    }
}

export default PublicChatBoat