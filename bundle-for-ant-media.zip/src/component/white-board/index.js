import React from "react"
import './style.css'
import Paper from 'paper';

let pencilLaye, path, textLayer, typeText,
    squareLayer, rectangleLayer, circleLayer, triangleLayer,
    square, rectangle, circle, triangle;
class WhiteBoardComponent extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            activePenBtn: false,
            activeTextBtn: false,
            text_Update: ""
        }
    }
    
    componentWillUnmount(){
        this.props.socket.emit('leaveRoom',this.props.room)
    }
    componentDidMount() {
        // adding paper.js / adding canvas
        this.props.socket.emit('joinRoom',this.props.room)
        this.props.socket.on('receiveWhiteBoard',(message)=>{
            console.log(message)
            alert(message)
        })
        Paper.install(window);
        const canvas = document.getElementById("wihite_board");
        Paper.setup(canvas);
        // adding layers for multi task
        pencilLaye = new Paper.Layer();
        textLayer = new Paper.Layer();
        squareLayer = new Paper.Layer();
        rectangleLayer = new Paper.Layer();
        circleLayer = new Paper.Layer();
        triangleLayer = new Paper.Layer();


        // by defualt all layers all false
        pencilLaye.visible = false;
        textLayer.visible = false;
        squareLayer.visible = false;
        rectangleLayer.visible = false;
        circleLayer.visible = false;
        triangleLayer.visible = false;
    }
    pencilTool() {
        Paper.view.onMouseDown = (event) => {
            path = new Paper.Path();
            path.strokeColor = '#E4141B'
            path.fillColor = "#E4141B"
            path.strokeWidth = 2
        };
        Paper.children = path

        Paper.view.onMouseDrag = (event) => {
            var step = event.delta;
            step.angle += 90;

            var top = event.point;
            var bottom = event.point;
            path.add(top);
            path.insert(0, bottom);
            path.smooth();
        }
        Paper.view.onMouseUp = (event) => {
            path.add(event.point);
            path.closed = true;
            path.smooth();
        }
        let body={
            paper:Paper,
            room:this.props.room
        }
        this.props.socket.emit('whiteBoard',body)
    }
    undo() {
        if (pencilLaye.visible && Paper.project.activeLayer.lastChild) {
            Paper.project.activeLayer.lastChild.remove()
        }
    }
    pencilToolControl() {
        if (!this.state.activePenBtn) {
            pencilLaye.activate()
            pencilLaye.visible = true;
            textLayer.visible = false;
            squareLayer.visible = false;
            rectangleLayer.visible = false;
            circleLayer.visible = false;
            triangleLayer.visible = false;
            this.setState({
                activeTextBtn: false,
                activePenBtn: true,
            })
            Paper.view.update()
            this.pencilTool()
        } else {
            this.setState({
                activePenBtn: false
            })
            pencilLaye.visible = false
        }
    }
    clearCanvas() {
        if (pencilLaye.visible) {
            Paper.project.activeLayer.removeChildren()
        }
    }
    writeTextTool() {
        typeText = new Paper.PointText({
            point: [25, 25],
            content: this.state.text_Update,
            fillColor: 'black',
            fontFamily: 'arial',
            fontSize: 16,
            group: {
                lineCount: 0
            }
        });
        // textLayer.position = Paper.view.center
        let keys = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
        let line = 100;
        Paper.view.onKeyDown = (event) => {
            let keyPress = keys.find((e) => e === event.key)
            if (event.key === keyPress) {
                typeText.content += keyPress
                let countLineChange = typeText.group.lineCount;
                if (typeText.content.length > line) {
                    ++countLineChange
                    if (typeText.group.lineCount !== countLineChange) {
                        typeText.content += '\n'
                        typeText.group.lineCount = countLineChange
                        line = line + 100
                    }
                }
            }
        }
        // let spacePress = true
        // let deletePress = true
        window.addEventListener("keydown", this.keyboardSpecialButtons)
    }
    keyboardSpecialButtons(e) {
        if (e.keyCode === 32) {
            // if (spacePress) {
            let a = typeText.content += ' '
            typeText.content = a.replace(/  +/g, ' ');
            // spacePress = false
            // }
            e.preventDefault()
            return false
        }
        if (e.keyCode === 8 || e.keyCode === 46) {
            // if (deletePress) {
            let del = [...typeText.content]
            let edited = del.slice(0, del.length - 1).toString().replace(/,/g, '')
            typeText.content = String(edited);
            // deletePress = false
            // }
            e.preventDefault()
            return false
        }
        // })
    }
    writeText() {
        if (!this.state.activeTextBtn) {
            textLayer.activate()
            pencilLaye.visible = false
            textLayer.visible = true
            squareLayer.visible = false;
            rectangleLayer.visible = false;
            circleLayer.visible = false;
            triangleLayer.visible = false;
            this.setState({
                activePenBtn: false,
                activeTextBtn: true
            })
            Paper.view.update()
            this.writeTextTool()
        } else {
            this.setState({
                activeTextBtn: false
            })
            textLayer.visible = false
        }
    }
    increaseSize() {
        if (typeText && typeText.fontSize < 25) {
            typeText.fontSize += 1
        }
    }
    decreaseSize() {
        if (typeText && typeText.fontSize > 16) {
            typeText.fontSize -= 1
        }
    }
    makeSquare() {
        squareLayer.activate()
        squareLayer.visible = true;
        textLayer.visible = false
        pencilLaye.visible = false
        rectangleLayer.visible = false;
        circleLayer.visible = false;
        triangleLayer.visible = false;

        var sq = new Paper.Rectangle(new Paper.Point(50, 50), new Paper.Point(150, 150));
        square = new Paper.Path.Rectangle(sq);
        square.fillColor = '#e9e9ff';
        square.selected = true;
    }
    makeRectangle() {
        rectangleLayer.activate()
        rectangleLayer.visible = true;
        squareLayer.visible = false;
        textLayer.visible = false
        pencilLaye.visible = false
        circleLayer.visible = false;
        triangleLayer.visible = false;

        var rect = new Paper.Rectangle(new Paper.Point(50, 40), new Paper.Point(180, 100));
        rectangle = new Paper.Path.Rectangle(rect);
        rectangle.fillColor = '#e9e9ff';
        rectangle.selected = true;
    }
    makeTriangle() {
        triangleLayer.activate()
        triangleLayer.visible = true;
        rectangleLayer.visible = false;
        squareLayer.visible = false;
        textLayer.visible = false
        pencilLaye.visible = false
        circleLayer.visible = false;

        // Create a triangle shaped path 
        triangle = new Paper.Path.RegularPolygon(new Paper.Point(80, 70), 3, 50);
        triangle.fillColor = '#e9e9ff';
        triangle.selected = true;
    }
    makeCircle() {
        circleLayer.activate()
        circleLayer.visible = true;
        rectangleLayer.visible = false;
        squareLayer.visible = false;
        textLayer.visible = false
        pencilLaye.visible = false
        triangleLayer.visible = false;

        // Create a triangle shaped path 
        circle = new Paper.Path.Circle(new Paper.Point(100, 70), 50);
        circle.fillColor = '#e9e9ff';
        circle.selected = true;

        circle.onMouseDrag = (event) => {
            circle.position.x = event.point.x
            circle.position.y = event.point.y
        }
    }
    
    render() {
        let active = "activeBtn"
        let in_active = "tools-btn-in"
        return (
            <div className="white-board">
                <div className="tools">
                    <div className="header-board">
                        <div className="minimize-box">
                            <button>&minus;</button>
                        </div>
                        <div className="wb-message">
                            <span>Canvas learning</span>
                        </div>
                        <div className="wb-shape"></div>
                    </div>
                    <div className="tools-options">
                        <button className={this.state.activePenBtn ? active : in_active} onClick={this.pencilToolControl.bind(this)}>
                            <span className="glyphicon glyphicon-pencil"></span>
                        </button>
                        {/* <button className={this.state.activeTextBtn ? active : in_active} onClick={this.writeText.bind(this)}>T</button> */}
                        {/* <button className="tools-btn-in" onClick={this.increaseSize.bind(this)} >A</button> */}
                        {/* <button className="tools-btn-in" onClick={this.decreaseSize.bind(this)}>a</button> */}
                        {/* <div className="dropdown">
                            <button className="tools-btn-in">&#9635;</button>
                            <div className="dropdown-content">
                                <div className="li" onClick={this.makeSquare.bind(this)}>
                                    <div className="li-left">
                                        <span>&#9634; </span>
                                    </div>
                                    <div className="li-right">
                                        <span>Square</span>
                                    </div>
                                </div>
                                <div className="li" onClick={this.makeRectangle.bind(this)}>
                                    <div className="li-left">
                                        <span>&#9645; </span>
                                    </div>
                                    <div className="li-right">
                                        <span>Rectangle</span>
                                    </div>
                                </div>
                                <div className="li" onClick={this.makeTriangle.bind(this)}>
                                    <div className="li-left">
                                        <span>&#9651; </span>
                                    </div>
                                    <div className="li-right">
                                        <span>Triangle</span>
                                    </div>
                                </div>
                                <div className="li" onClick={this.makeCircle.bind(this)}>
                                    <div className="li-left">
                                        <span>&#9711; </span>
                                    </div>
                                    <div className="li-right">
                                        <span>Circle</span>
                                    </div>
                                </div>
                            </div>
                        </div> */}
                        <button disabled={!this.state.activePenBtn} className="tools-btn-in" onClick={this.undo.bind(this)}>&#8630;</button>
                        <button disabled={!this.state.activePenBtn} className="tools-btn-in" onClick={this.clearCanvas.bind(this)}>
                            <span className="glyphicon glyphicon-erase"></span>
                        </button>
                    </div>
                </div>
                <canvas id="wihite_board" className="canvasApp"></canvas>
            </div>
        )
    }
}

export default WhiteBoardComponent