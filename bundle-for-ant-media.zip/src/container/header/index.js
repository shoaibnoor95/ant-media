import React from "react"
import './style.css'
import Options from '../../assets/icons/icons-actions-overflow.svg'

export default function VeziuHeader() {
    return (
        <div className="header-parent">
            <div className="header-child-primary">
                <div className="logo">
                    <span>VEZIU</span>
                </div>
                <div className="title">
                    <span>Veziu Meeting Room</span>
                </div>
            </div>
            <div className="header-child-shap"></div>
            <div className="header-child-secondary">
                <div className="time-count">
                    <span className="hr">11</span>
                    <span className="doted"> :</span>
                    <span className="min"> 45</span>
                    <span className="doted"> :</span>
                    <span className="sec"> 25</span>
                </div>
                <div className="mobile-view-option">
                    <button className="options-btn">
                        <img src={Options} alt="options"/>    
                    </button>
                </div>
                <div className="live-message">
                    <div className="circle-shape-small"></div>
                    <div className="live-text">
                        <span>Live Event</span>
                    </div>
                </div>
                <div className="user-count">
                    <span className="users">10</span>
                    <span className="doted"> :</span>
                    <span className="user-text"> ATTENDEES</span>
                </div>
            </div>
        </div>
    )
}