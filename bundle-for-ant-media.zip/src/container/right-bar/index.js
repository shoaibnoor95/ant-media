import './style.css'
// import MicEnable from "../../assets/icons/icons-actions-mic-enable.svg";
// import VideoEnable from "../../assets/icons/icons-actions-video-enable.svg";
// import GroupUsers from "../../assets/icons/icons-actions-users-inactive.svg";
// import PublicMessage from "../../assets/icons/icons-actions-chat-fill-inactive.svg";
// import PolliFill from "../../assets/icons/icons-actions-poll-fill-inactive.svg";
// import Notes from "../../assets/icons/icons-actions-notes-inactive.svg";
// import WhiteBoard from "../../assets/icons/icons-actions-whiteboard-inactive.svg";
// import ScreenShare from "../../assets/icons/icons-actions-share-fill-inactive.svg";
// import Layout from "../../assets/icons/icons-actions-change-layout-inactive.svg";
// import Settings from "../../assets/icons/icons-actions-settings-fill-inactive.svg";
// import Exit from "../../assets/icons/icons-actions-exit-inactive.svg";
import { useState } from 'react';
import PublicChatBoat from '../../component/public-chat'
import WhiteBoardComponent from '../../component/white-board'
import NotesForPublic from '../../component/notes'
import PollingComponent from '../../component/polling'
import React from 'react'
export default function RightBar(props) {
    const [publicChat, publicChatSet] = useState(false)
    const [whiteboard, whiteboardSet] = useState(false)
    const [notes, setNotes] = useState(false)
    const [poll, setPoll] = useState(false)

    return (
        <div className="right-bar">
            {/* <div>Shoaib</div> */}
            <div className="call-action">
                <button className="rtc-btn" data-title="Mic">
                    <img src={'/assets/icons/icons-actions-mic-enable.svg'} alt="mic" />
                </button>
                <button className="rtc-btn" data-title="Video">
                    <img src={'/assets/icons/icons-actions-video-enable.svg'} alt="video" />
                </button>
            </div>
            <div className="options">
                <button className="opt-btn" option-title="Users">
                    <img src={'/assets/icons/icons-actions-users-inactive.svg'} alt="GroupUsers" />
                </button>
                <button onClick={() => {
                    setNotes(false)
                    setPoll(false)
                    whiteboardSet(false)
                    publicChatSet(!publicChat)
                }} className="opt-btn" option-title="Public chat">
                    <img src={'/assets/icons/icons-actions-chat-fill-inactive.svg'} alt="PublicMessage" />
                </button>
                <button onClick={() => {
                    setPoll(!poll)
                    setNotes(false)
                    whiteboardSet(false)
                    publicChatSet(false)
                }} className="opt-btn" option-title="Polls">
                    <img src={'/assets/icons/icons-actions-poll-fill-inactive.svg'} alt="PolliFill" />
                </button>
                <button onClick={() => {
                    setNotes(!notes)
                    setPoll(false)
                    whiteboardSet(false)
                    publicChatSet(false)
                }} className="opt-btn" option-title="Notes">
                    <img src={'/assets/icons/icons-actions-notes-inactive.svg'} alt="Notes" />
                </button>
                <button className="opt-btn" option-title="Screen share">
                    <img src={'/assets/icons/icons-actions-share-fill-inactive.svg'} alt="ScreenShare" />
                </button>
                <button onClick={() => {
                    setPoll(false)
                    setNotes(false)
                    publicChatSet(false)
                    whiteboardSet(!whiteboard)
                }} className="opt-btn" option-title="White board">
                    <img src={'/assets/icons/icons-actions-whiteboard-inactive.svg'} alt="WhiteBoard" />
                </button>
            </div>
            <div className="settings">
                <button className="opt-btn" option-title="Layout">
                    <img src={'/assets/icons/icons-actions-change-layout-inactive.svg'} alt="Layout" />
                </button>
                <button className="opt-btn" option-title="Settings">
                    <img src={'/assets/icons/icons-actions-settings-fill-inactive.svg'} alt="Settings" />
                </button>
                <button className="opt-btn" option-title="Exit meeting">
                    <img src={'/assets/icons/icons-actions-exit-inactive.svg'} alt="Exit" />
                </button>
            </div>

            {publicChat ? (
                <PublicChatBoat room={props.room} socket={props.socket} />
            ) : null}
            {whiteboard ? (
                <WhiteBoardComponent room={props.room} socket={props.socket} />
            ) : null}
            { notes ? (
                <NotesForPublic room={props.room} socket={props.socket} />
            ) : null}
            { poll ?(
                <PollingComponent room={props.room} socket={props.socket}/>
            ):null}
        </div>
    )
}
// const mapStateToProps = ()=>{
//     return 
// }

// export default connect()(RightBar)