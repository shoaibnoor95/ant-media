const actionTypes = {
    POOLING_JSON : "POOLING_JSON"
}

export default actionTypes