import actionTypes from './actionTypes'

export function poolingDispatch(payload) {
    return {
        type: actionTypes.POOLING_JSON,
        payload
    }
}