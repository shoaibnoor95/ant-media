import actionTypes from '../middle/actionTypes';

const PoolingRed = (state = {
    question_json: [],
}, action) => {
    switch (action.type) {
        case actionTypes.POOLING_JSON: {
            return state = {
                ...state,
                question_json: action.payload
            }
        }
        default: { }
    }
    return state;
}
export default PoolingRed;