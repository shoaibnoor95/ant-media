const express = require('express');
const path = require('path');
const fs = require('fs');
const http = require('http');
const https = require('https');
const sio = require('socket.io');
const favicon = require('serve-favicon');
const compression = require('compression');

const app = express(),
  options = { 
    key: fs.readFileSync(__dirname + '/cert.key'),
    cert: fs.readFileSync(__dirname + '/cert.pem')
  },
  port = process.env.PORT || 3030,
  server = http.createServer(app).listen(port)
    // https.createServer(options, app).listen(port),
  io = sio(server);
// compress all requests
app.use(compression());
app.use(express.static(path.join(__dirname, 'public')));
app.use((req, res) => res.sendFile(__dirname + '/public/index.html'));
app.use(favicon('./public/favicon.ico'));
// Switch off the default 'X-Powered-By: Express' header
app.disable('x-powered-by');
io.sockets.on('connection', socket => {
 
  socket.on('sendMessage',(message)=>{
    socket.broadcast.to(message.room).emit('receiveMessage',message) 
  })

  socket.on('whiteBoard',(message)=>{
    console.log(message,'message')
    socket.broadcast.to(message.room).emit('receiveWhiteBoard',message) 
  })
  
  socket.on('joinRoom',(room)=>{
    socket.join(room)
  })

  socket.on('createPol',(message)=>{
    socket.broadcast.to(message.room).emit('receivePol',message) 
  
  })

  socket.on('leaveRoom',(room)=>{
    socket.leave(room)
  })
});