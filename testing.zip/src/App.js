import VezuRouter from './component/index'
import { Provider } from 'react-redux'
import store from './store/index'
import React from 'react'


function App() {
  return (
    <Provider store={store}>
      <VezuRouter />
    </Provider>
  );
}

export default App;
