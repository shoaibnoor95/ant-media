import React from 'react'
import { connect } from 'react-redux'
import './style.css'
import { isMobile } from 'react-device-detect'

class Polling extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            poolingFlag: true,
            booleanOption: false,
            customOption: false,
            booleanT: false,
            booleanF: false,
            question_data: [],
            question: "",
            inputList: [
                {
                    value: "",
                    option: "A"
                }
            ]
        }
    }
    handleInputChange = (e, index) => {
        const { name, value } = e.target;
        const list = [...this.state.inputList];
        list[index].value = value;
        this.setState({
            inputList: list
        })
    };
    handleAddClick = () => {
        let opt;
        if (this.state.inputList.length === 1) {
            opt = "B"
        }
        if (this.state.inputList.length === 2) {
            opt = "C"
        }
        if (this.state.inputList.length === 3) {
            opt = "D"
        }
        if (this.state.inputList.length < 4) {
            this.setState({
                inputList: [...this.state.inputList, { value: "", option: opt }]
            })
        }
    };
    answerChange(e) {
        let opt = e.target.value
        let name = e.target.name
        if (name === "booleanT") {
            this.setState({
                booleanT: opt,
                booleanF: !opt,
            })
        } else {
            this.setState({
                booleanT: !opt,
                booleanF: opt,
            })
        }
        // let array = {
        //     true_1: this.state.booleanT,
        //     false_0: this.state.booleanF
        // }
    }
    onChangeInputs(e) {
        let name = e.target.name
        let value = e.target.value
        this.setState({
            [name]: value
        })
    }
    startPolling() {
        let Q = this.state.question;
        let T = this.state.booleanOption;
        // let C = this.state.customOption;
        let obj = {}
        if (T) {
            obj.answer = {
                true: this.state.booleanT,
                false: this.state.booleanF
            }
        } else {
            obj.answer = this.state.inputList
        }
        obj.question = Q

        this.setState({
            question_data: this.state.question_data.concat(obj)
        })

        console.log("-=-=-=-=-=-=-=-=-=-=-=-=-=-=", T)
        console.log(this.state.question_data)
        console.log("-=-=-=-=-=-=-=-=-=-=-=-=-=-=")
    }
    render() {
        return (
            <div className="pol-bx">
                <div className="pol-had">
                    <div className="pol-h">
                        <span>Polling</span>
                    </div>
                    <div className="pol-shape"></div>
                    {isMobile ? (
                        <div className="wb-user-act">
                            <span
                                className="close"
                                onClick={this.props.pollingView}
                            >&times;</span>
                        </div>
                    ) : null}
                </div>
                <div className="pol-cont">
                    <div className="info-b">
                        <span>Fill out your polling details below.</span>
                    </div>
                    <div className="ques-box">
                        <div className="q-h">
                            <span>Ask a question</span>
                        </div>
                        <div className="poll-ad-q">
                            <textarea value={this.state.question} onChange={(e) => this.onChangeInputs(e)} style={{ resize: 'none' }} name="question" ></textarea>
                        </div>
                    </div>
                    <div className="res-typ">
                        <div className="res-h">
                            <span>Response types</span>
                        </div>
                        <div className="res-opt">
                            <button onClick={() => {
                                this.setState({
                                    booleanOption: true,
                                    customOption: false
                                })
                            }} className="opt-on">True / False</button>
                            <button onClick={() => {
                                this.setState({
                                    booleanOption: false,
                                    customOption: true
                                })
                            }} className="opt-tw">A / B / C / D</button>
                        </div>
                    </div>
                    {this.state.customOption || this.state.booleanOption ? (
                        <div className="q-h">
                            <span>Response Choice</span>
                        </div>
                    ) : null}
                    {this.state.booleanOption ? (
                        <div className="res-chs">
                            <div className="res-ch-t">
                                <label className="container">True
                                    <input onChange={(e) => this.answerChange(e)} type="radio" checked={this.state.booleanT} name="booleanT" />
                                    <span className="checkmark"></span>
                                </label>
                                <label className="container">False
                                    <input onChange={(e) => this.answerChange(e)} type="radio" checked={this.state.booleanF} name="booleanF" />
                                    <span className="checkmark"></span>
                                </label>
                            </div>
                        </div>
                    ) : null}
                    {this.state.customOption ? (
                        <div className="res-chs">
                            <div className="res-ch-opt">
                                {this.state.inputList.map((v, i) => {
                                    return (
                                        <div key={i} className="option">
                                            <div className="opt-li">
                                                <span>{v.option}.</span>
                                            </div>
                                            <div className="opt-dd">
                                                <input name={v.option} onChange={(e) => this.handleInputChange(e, i)} value={v.value} type="text" placeholder={`Option ${v.option}`} />
                                            </div>
                                        </div>
                                    );
                                })}
                                {this.state.inputList.length < 4 ? (
                                    <div className="add-opt">
                                        <button onClick={this.handleAddClick}>
                                            <span className="glyphicon glyphicon-plus"></span>
                                        </button>
                                    </div>
                                ) : null}
                            </div>
                        </div>
                    ) : null}
                    <div className="conf-box">
                        <button
                            onClick={this.startPolling.bind(this)}
                            className={this.state.poolingFlag ? 'dispoll' : "poll"}
                        // disabled={this.state.poolingFlag}
                        >
                            Start Poll
                        </button>
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {

    }
}
const mapDispatchToProps = (dispatch) => {
    return {

    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Polling);