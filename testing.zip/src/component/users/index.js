import React from 'react'
import { connect } from 'react-redux'
// import classnames from 'classnames';
import Me from '../me';
import './style.css'
import { isMobile } from 'react-device-detect'

class Users extends React.Component {


    render() {
        const {
            // peer,
            // audioConsumer,
            // videoConsumer,
            // audioMuted,
            // allConsumers,
            peersArray,
        } = this.props;
        return (
            <div className='users-dp-container' >
                {/* {this.props.peersArray.length === 0 ? ( */}
                {!isMobile ? (
                    <div className="me-profile">
                        <Me
                            isCameraOff={this.props.isCameraOff}
                            isMicMuted={this.props.isMicMuted}
                            cont_name={this.props.localData}
                        />
                    </div>
                ) : null}
                {/* ) : (
                    <div className="user-info">
                        <div className="user-n">
                            <div className="wb-message" style={{ width: "12em" }}>
                                <span style={{ fontSize: "1.15em" }}>My Name</span>
                            </div>
                            <div className="wb-shape-nt"></div>
                        </div>
                        <div className="user-p">
                            <img src={'/assets/img/adjust-tie.jpeg'} alt="profile" />
                        </div>
                    </div>
                )} */}
                {/* users display------- */}
                <div className='co-header'>
                    <div className='co-head-box'>
                        <div className='brnd-h3-box'>
                            <span className='brnd-text' >
                                Users
                            </span>
                        </div>
                        <div className='brnd-shap'></div>
                        {isMobile ? (
                            <div className="wb-user-act">
                                <span
                                    className="close"
                                    onClick={this.props.allUsersView}
                                >&times;</span>
                            </div>
                        ) : null}
                    </div>
                </div>
                {/* all contributers list */}
                <div className={['contr-box', this.props.users.length <= 1 ? ' contr-box-height' : null]}>
                    {this.props.users.length > 0 && this.props.users.map((v, i) => {
                        return (
                            <div key={i} className="cont-li">
                                <div className="avt"></div>
                                <div className="cont-li-midale">
                                    <div className="cont-name">
                                        <span>{v}</span>
                                    </div>
                                    <div className="cont-rtc">
                                        <button
                                            className={`dp-resp contri-audio-on`}
                                            disabled={true}
                                        ></button>
                                        <button
                                            className={`dp-resp contri-video-on`}
                                            disabled={true}
                                        ></button>
                                    </div>
                                </div>
                                <div className="cont-li-right">
                                    <button className="user-option options"></button>
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    // const peersArray = Object.values(state.peers);

    // const peer = state.peers[];

    // const consumersArray = peer.consumers
    //     .map((consumerId) => state.consumers[consumerId]);
    // const audioConsumer =
    //     consumersArray.find((consumer) => consumer.track.kind === 'audio');
    // const videoConsumer =
    //     consumersArray.find((consumer) => consumer.track.kind === 'video');
    // console.log(peersArray)
    return {
        // peer,
        // audioConsumer,
        // videoConsumer,
        // audioMuted: me.audioMuted,
        // allConsumers: consumersArray,
        peersArray: [],
    }
}
const mapDispatchToProps = (dispatch) => {
    return {

    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Users);