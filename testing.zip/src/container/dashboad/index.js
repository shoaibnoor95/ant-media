import React from 'react'
import { WebRTCAdaptor } from "../../component/js/webrtc_adaptor.js"
import VeziuHeader from '../header'
import RightBar from '../right-bar'
import Me from '../../component/me'
// right bar collection
import PublicChatBoat from '../../component/public-chat'
import WhiteBoardComponent from '../../component/white-board'
import NotesForPublic from '../../component/notes'
import PollingComponent from '../../component/polling'
import Users from '../../component/users'



// import Peers from '../../component/peers'
import './style.css'
import './style.main.css'

import io from 'socket.io-client'
import { isMobile } from 'react-device-detect'

let that;
let player_div_style;
let player_video_style;
let player_bottom = "";
let player_bottom_style = "";
let player_bottom_style_shape = "";
let player_dp_name = "";


export default class dashboard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            token: null,
            onlineState: false,
            meOptionsMobile: false,
            mute_mic_button: false,
            unmute_mic_button: false,
            streamId: null,
            webRTCAdaptor: null,
            playOnly: false,
            volume_change_input: null,
            roomName: 'room1',
            publishStreamId: null,
            isDataChannelOpen: false,
            isMicMuted: false,
            isCameraOff: false,
            roomTimerId: -1,
            pc_config: {
                'iceServers': [{
                    'urls': 'stun:stun1.l.google.com:19302'
                }]
            },
            sdpConstraints: {
                OfferToReceiveAudio: false,
                OfferToReceiveVideo: false

            },
            mediaConstraints: {
                video: true,
                audio: true
            },
            turn_on_camera_button: false,
            join_publish_button: false,
            appName: null,
            stop_publish_button: false,
            websocketURL: null,
            turn_off_camera_button: false,
            btn_p_chat: null,
            turnOnLocalCamera: false,
            roomTimerId: -1,
            p_chat: null,
            roomOfStream: [],
            streamsList: [],
            host: false,
            host_id: '',
            host_class_value: "item303-host",
            host_box_value: "video_cont3030-01",

            // right bar states
            users: isMobile ? false : true,
            public_chat: false,
            notes: false,
            polling: false,
            shareState: 'off',
            whiteboard: false,
            // header states
            headerOption: false,
            // modal settings states
            modalSetting: false,
            personalSetting: true,
            viewersSetting: false,
            active_set: "modal-btn-opt-active",
            active_View: "",
            personal_Setting_obj: {
                animations: "on",
                audioAlertsPublicPrivate: "0ff",
                popupAlertsPublicPrivate: "on",
                audioAlertsNewConsumer: "0ff",
                popupAlertsNewConsumer: "on",
            },
            viewers_Setting_obj: {
                shareWebcam: "on",
                viewersWebcam: "0ff",
                shareMicrophone: "on",
                publicChatMessage: "on",
                privateChatMessage: "0ff",
            }

        }
        this.socket = io.connect();
        that = this
    }
    settingsViews = () => {
        this.setState({
            modalSetting: !this.state.modalSetting
        })
    }
    handlePersonalObj(e) {
        let value = e.target.value
        let name = e.target.name
        this.setState({
            personal_Setting_obj: {
                ...this.state.personal_Setting_obj,
                [name]: value === "on" ? "off" : "on"
            }
        })
    }
    handleViewersObj(e) {
        let value = e.target.value
        let name = e.target.name
        this.setState({
            viewers_Setting_obj: {
                ...this.state.viewers_Setting_obj,
                [name]: value === "on" ? "off" : "on"
            }
        })
    }
    headerMenu = () => {
        this.setState({
            headerOption: !this.state.headerOption
        })
    }
    publicChatView = () => {
        this.setState({
            public_chat: !this.state.public_chat,
            // users: false,
            polling: false,
            notes: false,
            // whiteboard: false,
            shareScreen: false,
        })
    }
    allUsersView = () => {
        if (isMobile) {
            this.setState({
                users: !this.state.users,
                public_chat: false,
                notes: false,
                polling: false,
                // whiteboard: false,
                shareScreen: false,
            })
        }
    }
    meNotesView = () => {
        this.setState({
            notes: !this.state.notes,
            // users: false,
            public_chat: false,
            polling: false,
            shareScreen: false,
            // whiteboard: false
        })
    }
    pollingView = () => {
        this.setState({
            polling: !this.state.polling,
            // users: false,
            public_chat: false,
            notes: false,
            // whiteboard: false,
            shareScreen: false,
        })
    }
    whiteboardView = () => {
        this.setState({
            whiteboard: !this.state.whiteboard,
            // public_chat: false,
            // users: false,
            // polling: false,
            // shareScreen: false,
            // notes: false,
        }, () => {
            this.updateUIforWhiteBoard()
        })
    }
    updateUIforWhiteBoard() {
        if (this.state.whiteboard) {
            // console.log("whiteboard open")
            let get_host_div = document.querySelector(".video_cont3030-01")
            if (get_host_div !== null) {
                this.props.whiteBoardDisplay(
                    "item303-host-with-board",
                    "video_cont3030-01-with-board"
                )
                get_host_div.setAttribute("class", 'video_cont3030-01-with-board')
            }
        } else {
            let get_host_div = document.querySelector(".video_cont3030-01-with-board")
            if (get_host_div !== null) {
                this.props.whiteBoardDisplay(
                    "item303-host",
                    "video_cont3030-01"
                )
                get_host_div.setAttribute("class", 'video_cont3030-01')
            }
        }
    }
    static getDerivedStateFromProps(props, state) {
        if (state.streamsList.length > 1) {
            let parent = document.querySelector(".item303-util")
            let parent_mob = document.querySelector(".item303-util-101")
            try {
                if (parent !== null) {
                    let class_s = parent.firstElementChild.getAttribute("class")
                    if (class_s === "single-player") {
                        parent.removeChild(parent.firstChild)
                    }
                }
                if (parent_mob !== null) {
                    let class_s = parent_mob.firstElementChild.getAttribute("class")
                    if (class_s === "single-player") {
                        parent_mob.removeChild(parent_mob.firstChild)
                    }
                }
            } catch (err) {
                console.log("uppppspspspspsppsspp")
            }
        }

        return null
    }
    componentDidMount() {
        sessionStorage.clear()
        this.setState({
            isShow: true,
        });
        this.initiateWebrtc();
    }
    muteLocalMic = () => {
        this.state.webRTCAdaptor.muteLocalMic();
        this.setState({ isMicMuted: true });
        this.handleMicButtons();
        this.sendNotificationEvent("MIC_MUTED");
    }
    unmuteLocalMic = () => {
        this.state.webRTCAdaptor.unmuteLocalMic();
        this.setState({
            isMicMuted: false
        })
        this.handleMicButtons();
        this.sendNotificationEvent("MIC_UNMUTED");
    }
    initiateWebrtc() {
        this.state.webRTCAdaptor = new WebRTCAdaptor(
            {
                // websocket_url: 'wss://demo.inquisitives.com:5443/WebRTCAppEE/websocket',
                websocket_url: 'ws://ams-c-appli-196g44adtdkgx-351388843.us-east-1.elb.amazonaws.com/WebRTCAppEE/websocket',
                mediaConstraints: this.state.mediaConstraints,
                peerconnection_config: this.state.pc_config,
                sdp_constraints: this.state.sdpConstraints,
                localVideoId: "localVideo",
                isPlayMode: false,
                debug: true,
                callback: function (info, obj) {
                    if (info == "initialized") {
                        console.log('initializeds')
                        that.setState({
                            join_publish_button: false,
                            stop_publish_button: true,
                            onlineState: true

                        })

                        //called by JavaScript SDK when WebSocket is connected. 
                    }
                    else if (info == "joinedTheRoom") {
                        //called when this client is joined the room
                        //obj contains streamId field which this client can use to publish to the room.
                        //obj contains also the active streams in the room so that you can play them directly.
                        //In order to get the streams in the room periodically call `getRoominfo`
                        const room = obj.ATTR_ROOM_NAME;
                        const roomOfStream = that.state.roomOfStream
                        roomOfStream[obj.streamId] = room;
                        that.setState({
                            publishStreamId: obj.streamId,
                            roomOfStream
                        })
                        //[obj.streamId] = room;
                        // console.log("joined the room: " + roomOfStream[obj.streamId]);


                        if (that.state.playOnly) {
                            that.setState({
                                join_publish_button: true,
                                stop_publish_button: false,
                                isCameraOff: true

                            })
                            that.handleCameraButtons();
                        }
                        else {
                            that.publish(obj.streamId, that.state.token);
                        }

                        if (obj.streams != null) {
                            obj.streams.forEach(function (item) {
                                // console.log("Stream joined with ID: " + item);
                                that.state.webRTCAdaptor.play(item, that.state.token,
                                    that.state.roomName);
                            });
                            that.setState({ streamsList: obj.streams });
                            // let host = {
                            //     streamsList: that.state.streamsList,
                            //     room: that.state.roomName
                            // }
                            // that.socket.emit('hostInfo', host)
                        }
                        that.setState({
                            roomTimerId: setInterval(() => {
                                that.state.webRTCAdaptor.getRoomInfo(that.state.roomName, that.state.publishStreamId);
                            }, 5000)
                        });

                        console.log("**************************************************************")
                        console.log("joinedTheRoom")
                        console.log("**************************************************************")
                    }
                    else if (info == "newStreamAvailable") {
                        //called when client is ready to play WebRTC stream.
                        if (that.state.streamsList.length > 1 && !that.state.host) {
                            // alert("host mil gia")
                            that.playHost(obj)
                            that.setState({
                                host: true,
                                host_id: obj.streamId
                            })
                        }
                        if (that.state.streamsList.length > 1 && that.state.host_id !== obj.streamId) {
                            // alert("hos mila gia AAAAA")
                            that.playVideo(obj);
                        } else if (that.state.streamsList.length === 1) {
                            // alert("host ni mila gia AAAAA")
                            that.playVideoSinle(obj)
                        }

                        console.log("**************************************************************")
                        console.log("newStreamAvailable")
                        console.log("**************************************************************")

                    }
                    else if (info == "publish_started") {
                        that.setState({
                            join_publish_button: true,
                            stop_publish_button: false,
                        })
                        console.log("**************************************************************")
                        console.log("publish_started")
                        console.log("**************************************************************")

                        //called when stream publishing is started for this client		
                    }
                    else if (info == "publish_finished") {
                        //called when stream publishing has finished for this client
                        console.debug("publish finished");

                        console.log("**************************************************************")
                        console.log("publish_finished")
                        console.log("**************************************************************")

                    }
                    else if (info == "leavedFromRoom") {
                        //called when this client is leaved from the room  	
                    }
                    else if (info == "screen_share_stopped") {
                        console.log("screen share stopped");
                    }
                    else if (info == "browser_screen_share_supported") {
                        // screen_share_checkbox.disabled = false;
                        // camera_checkbox.disabled = false;
                        // screen_share_with_camera_checkbox.disabled = false;
                        // console.log("browser screen share supported");
                        // browser_screen_share_doesnt_support.style.display = "none";
                    }
                    else if (info == "closed") {
                        //called when websocket connection is closed	
                    }
                    else if (info == "play_finished") {
                        //called when a stream has finished playing	
                    }
                    else if (info == "streamInformation") {
                        //called when a stream information is received from the server. 
                        //This is the response of `getStreamInfo` method
                        that.streamInformation(obj)

                        console.log("**************************************************************")
                        console.log("streamInformation")
                        console.log("**************************************************************")

                    }
                    else if (info == "roomInformation") {
                        //Called by response of `getRoomInfo` when a room information is received from the server.
                        //It contains the array of the streams in the room.
                        for (let str of obj.streams) {
                            if (!that.state.streamsList.includes(str)) {
                                that.state.webRTCAdaptor.play(str, that.state.token,
                                    that.state.roomName);
                            }
                        }
                        // Checks if any stream has been removed, if yes, removes the view and stops webrtc connection.
                        for (let str of that.state.streamsList) {
                            if (!obj.streams.includes(str)) {
                                that.removeRemoteVideo(str);
                                that.removeRemoteVideoSingle(str)
                            }
                        }
                        //Lastly updates the current streamlist with the fetched one.
                        that.setState({
                            streamsList: obj.streams,
                        })

                        console.log("**************************************************************")
                        console.log("roomInformation", that.state.streamsList)
                        console.log("**************************************************************")

                    }
                    else if (info == "data_channel_opened") {
                        //called when data channel is opened
                        that.setState({ isDataChannelOpen: true });
                    }
                    else if (info == "data_channel_closed") {
                        // called when data channel is closed
                        that.setState({ isDataChannelOpen: false });

                    }
                    else if (info == "data_received") {
                        //called when data is received through data channel
                        that.handleNotificationEvent(obj)
                    }

                },
                callbackError: function (error, message) {
                    console.log(error, 'line', message)
                    //some of the possible errors, NotFoundError, SecurityError,PermissionDeniedError
                }
            });

    }
    // publish(streamName, token) {
    //    }
    switchVideoMode = (chbx) => {
        if (e.target.value == "screen") {
            this.state.webRTCAdaptor.switchDesktopCapture(this.state.publishStreamId);
        }
        else if (e.target.value == "screen+camera") {
            this.state.webRTCAdaptor.switchDesktopCaptureWithCamera(this.state.publishStreamId);
        }
        else {
            this.state.webRTCAdaptor.switchVideoCameraCapture(this.state.publishStreamId, chbx.value);
        }
    }
    switchVideoMode(mode) {
        if (mode == "screen") {
            this.state.webRTCAdaptor.switchDesktopCapture(publishStreamId);
        }
        else if (mode == "screen+camera") {
            this.state.webRTCAdaptor.switchDesktopCaptureWithCamera(publishStreamId);
        }
        else {
            this.state.webRTCAdaptor.switchVideoCameraCapture(publishStreamId, mode);
        }
    }
    turnOffLocalCamera = () => {
        this.state.webRTCAdaptor.turnOffLocalCamera();
        this.setState({
            isCameraOff: true
        })
        this.handleCameraButtons();
        this.sendNotificationEvent("CAM_TURNED_OFF");
    }

    turnOnLocalCamera = () => {
        this.state.webRTCAdaptor.turnOnLocalCamera();
        this.setState({
            isCameraOff: false
        })
        this.handleCameraButtons();
        this.sendNotificationEvent("CAM_TURNED_ON");
    }
    handleCameraButtons = () => {
        if (this.state.isCameraOff) {
            this.setState({
                turn_off_camera_button: true,
                turn_on_camera_button: false
            })
        } else {
            this.setState({
                turn_off_camera_button: false,
                turn_on_camera_button: true
            })
        }
    }
    joinRoom = () => {
        this.state.webRTCAdaptor.joinRoom(this.state.roomName, this.state.streamId);
    }
    leaveRoom = () => {
        this.state.webRTCAdaptor.leaveFromRoom(this.state.roomName);
        let availableNodes = document.getElementById("players").childNodes
        let availableNode = document.getElementById("player").childNodes
        for (var node in availableNodes) {
            if (node.tagName == 'DIV' && node.id != "localVideo") {
                document.getElementById("players").removeChild(availableNodes[node]);
            }
        }
        for (var node in availableNode) {
            if (node.tagName == 'DIV' && node.id != "localVideo") {
                document.getElementById("player").removeChild(availableNode[node]);
            }
        }
    }
    publish = (streamName, token) => {
        this.setState({
            publishStreamId: streamName
        })
        this.state.webRTCAdaptor.publish(streamName, token);
    }
    streamInformation = (obj) => {
        this.state.webRTCAdaptor.play(obj.streamId, this.state.token, this.state.roomName);
    }
    playHost = (obj) => {
        const host = [...this.state.streamsList]
        let video_host = document.getElementById("host_cont" + obj.streamId);
        if (video_host === null) {
            this.createHostVideo(obj.streamId);
            video_host = document.getElementById("host_cont" + obj.streamId);
        }
        video_host.srcObject = obj.stream;
    }
    playVideo = (obj) => {
        let video = document.getElementById("remoteVideo" + obj.streamId);
        if (video === null) {
            let clas = isMobile ? "col-xs-mobile" : "col-xs-2"
            this.createRemoteVideo(obj.streamId, "players", clas, "remoteVideo");
            video = document.getElementById("remoteVideo" + obj.streamId);
        }
        video.srcObject = obj.stream;

    }
    playVideoSinle = (obj) => {
        let singleNode = document.getElementById("player")
        if (singleNode.childNodes.length > 1) {
            let class_b = singleNode.firstElementChild.getAttribute("class")
            if (class_b === "single-player") {
                singleNode.removeChild(singleNode.firstChild)
                that.playSinglePerson(obj)
            }
        } else {
            that.playSinglePerson(obj)
        }
    }
    playSinglePerson = (obj) => {
        let singleVideo = document.getElementById("remoteVideoSigle" + obj.streamId);
        if (singleVideo === null) {
            this.createRemoteVideo(obj.streamId, "player", "single-player", "remoteVideoSigle");
            singleVideo = document.getElementById("remoteVideoSigle" + obj.streamId);
        }
        singleVideo.srcObject = obj.stream;
    }
    sendNotificationEvent = (eventType) => {
        if (this.state.isDataChannelOpen) {
            const notEvent = { streamId: this.state.streamId, eventType: eventType };
            this.state.webRTCAdaptor.sendData(this.state.publishStreamId, JSON.stringify(notEvent));
        } else {
            console.log("Could not send the notification because data channel is not open.");
        }
    }
    usersViewUpdate = () => {
        // if (this.state.streamsList.length === 1) {
        player_div_style = "single-player";
        player_video_style = "player-video-canvs";
        // }
        if (this.state.streamsList.length === 1) {
            player_bottom = "player-bottom-bar ";
            player_bottom_style_shape = "player-bar-shape"
            player_dp_name = "player-dp-name "
        } else {
            player_bottom = "consumer-bottom-bar ";
            player_bottom_style_shape = "consumer-bar-shape "
            player_dp_name = "consumer-dp-name"
        }
        // if (this.state.streamsList.length > 1 && this.state.streamsList.length <= 2) {
        //     player_div_style = "player-canvs-102";
        //     player_video_style = "player-video-canvs-102";
        // }
        // if (this.state.streamsList.length > 2 && this.state.streamsList.length <= 4) {
        //     player_div_style = "player-canvs-103";
        //     player_video_style = "player-video-canvs-103";
        // }
        // if (this.state.streamsList.length > 4 && this.state.streamsList.length <= 12) {
        //     player_div_style = "player-canvs-104";
        //     player_video_style = "player-video-canvs-104";
        //     player_bottom_style = "player-bottom-bar-104";
        //     player_bottom_style_shape = "player-bar-shape-104"
        // } else {
        //     player_bottom_style = "";
        //     player_bottom_style_shape = ""
        // }
    }
    createHostVideo = (streamId) => {
        let host_cont_box = document.getElementById("hosts");
        let host_div_box = document.createElement("div");
        host_div_box.className = this.state.host_box_value
        let host_div = document.createElement("div");
        host_div.id = "player" + streamId;
        host_div.className = 'video_cont'
        host_div.innerHTML = '<video id="host_cont' + streamId + '" autoPlay playsInline></video>';
        //  div can control player bar
        let player_bottom_bar = document.createElement("div");
        player_bottom_bar.className = "player-bottom-bar";
        //  div can control player  name
        let player_bottom_bar_user_name = document.createElement("div");
        player_bottom_bar_user_name.className = "player-dp-name"
        //  div can control player name value
        let player_name = document.createElement('span');
        player_name.innerText = streamId;
        player_bottom_bar_user_name.appendChild(player_name)
        //  div can control bar shape
        let player_bottom_bar_shape = document.createElement("div");
        player_bottom_bar_shape.className = "player-bar-shape " + player_bottom_style_shape;
        //  div can control bar extra feautres
        let player_bottom_bar_content = document.createElement("div");
        player_bottom_bar_content.className = "player-user-act"

        player_bottom_bar.appendChild(player_bottom_bar_user_name)
        player_bottom_bar.appendChild(player_bottom_bar_shape)
        player_bottom_bar.appendChild(player_bottom_bar_content)
        host_div_box.appendChild(host_div)
        host_div_box.appendChild(player_bottom_bar)

        // host_div_box.id = "player" + streamId;
        // host_div_box.innerHTML = '<video id="host_cont' + streamId + '" autoPlay playsInline></video>';
        host_cont_box.appendChild(host_div_box)
    }
    createRemoteVideo = (streamId, id, myClass, videoID) => {
        this.usersViewUpdate()
        // main div can control players
        let player = document.getElementById(id);
        //  div can control player
        let player_div = document.createElement("div");
        player_div.setAttribute("class", myClass)
        // player_div.className = player_div_style;
        player_div.id = "player" + streamId;
        //  div can control player video
        let player_video_div = document.createElement("div");
        // player_video_div.className = player_video_style;
        player_video_div.setAttribute("class", player_video_style);
        player_video_div.innerHTML = '<video id="' + videoID + streamId + '" autoPlay playsInline></video>';
        //  div can control player bar
        let player_bottom_bar = document.createElement("div");
        player_bottom_bar.setAttribute("class", player_bottom);
        // player_bottom_bar.className = 'player-bottom-bar ' + player_bottom_style;
        //  div can control player  name
        let player_bottom_bar_user_name = document.createElement("div");
        player_bottom_bar_user_name.setAttribute("class", player_dp_name);
        // player_bottom_bar_user_name.className = "player-dp-name"
        //  div can control player name value
        let player_name = document.createElement('span');
        player_name.innerText = streamId;
        player_bottom_bar_user_name.appendChild(player_name)
        //  div can control bar shape
        let player_bottom_bar_shape = document.createElement("div");
        player_bottom_bar_shape.setAttribute("class", player_bottom_style_shape);
        // player_bottom_bar_shape.className = "player-bar-shape " + player_bottom_style_shape;
        //  div can control bar extra feautres
        let player_bottom_bar_content = document.createElement("div");
        // player_bottom_bar_content.className = "player-user-act"
        player_bottom_bar_content.setAttribute("class", 'player-user-act');

        player_bottom_bar.appendChild(player_bottom_bar_user_name)
        player_bottom_bar.appendChild(player_bottom_bar_shape)
        player_bottom_bar.appendChild(player_bottom_bar_content)
        player_div.appendChild(player_video_div);
        player_div.appendChild(player_bottom_bar);

        // player_div.className = this.state.streamsList.length === 1 ? "single-player" : "col-xs-2"
        // player_div.id = "player" + streamId;
        // player_div.innerHTML = '<video id="remoteVideo' + streamId + '" autoPlay playsInline></video>';

        player.appendChild(player_div);
    }
    removeRemoteVideo = (streamId) => {
        var video = document.getElementById("remoteVideo" + streamId);
        if (video != null) {
            var player = document.getElementById("players" + streamId);
            video.srcObject = null;
            document.getElementById("players").removeChild(player);
        }
        this.state.webRTCAdaptor.stop(streamId);
    }
    removeRemoteVideoSingle = (streamId) => {
        var video = document.getElementById("remoteVideoSigle" + streamId);
        if (video != null) {
            var player = document.getElementById("player" + streamId);
            video.srcObject = null;
            document.getElementById("player").removeChild(player);
        }
        this.state.webRTCAdaptor.stop(streamId);
    }
    // startAnimation = () => {

    //     $("#broadcastingInfo")
    //         .fadeIn(
    //             800,
    //              ()=> {
    //                 $("#broadcastingInfo")
    //                     .fadeOut(
    //                         800,
    //                         function () {
    //                             var state =this.state.
    //                                 .signallingState(publishStreamId);
    //                             if (state != null
    //                                 && state != "closed") {
    //                                 var iceState = webRTCAdaptor
    //                                     .iceConnectionState(publishStreamId);
    //                                 if (iceState != null
    //                                     && iceState != "failed"
    //                                     && iceState != "disconnected") {
    //                                    that.startAnimation();
    //                                 }
    //                             }
    //                         });
    //             });

    // }
    handleNotificationEvent = (obj) => {
        // console.log("Received data : ", obj.event.data);
        var notificationEvent = JSON.parse(obj.event.data);
        if (notificationEvent != null && typeof (notificationEvent) == "object") {
            var eventStreamId = notificationEvent.streamId;
            var eventTyp = notificationEvent.eventType;

            if (eventTyp == "CAM_TURNED_OFF") {
                console.log("Camera turned off for : ", eventStreamId);
            } else if (eventTyp == "CAM_TURNED_ON") {
                console.log("Camera turned on for : ", eventStreamId);
            } else if (eventTyp == "MIC_MUTED") {
                console.log("Microphone muted for : ", eventStreamId);
            } else if (eventTyp == "MIC_UNMUTED") {
                console.log("Microphone unmuted for : ", eventStreamId);
            }
        }
    }

    handleMicButtons = () => {
        if (this.state.isMicMuted) {
            this.setState({
                mute_mic_button: true,
                unmute_mic_button: false
            })
        } else {
            this.setState({
                mute_mic_button: false,
                unmute_mic_button: true
            })
        }
    }
    componentWillUnmount() {
        this.props.socket.emit('leaveRoom', this.props.room)
    }
    whiteBoardDisplay = (value1, value2) => {
        this.setState({
            host_class_value: value1,
            host_box_value: value2
        })

    }
    render() {
        return (
            <div className="grid-container">
                <div className="item1">
                    <VeziuHeader
                        users={this.state.streamsList}
                        isOnLine={this.state.onlineState}
                        headerMenu={this.headerMenu}
                    />
                </div>
                {!isMobile ? (
                    <div className="item303">
                        {this.state.streamsList.length > 1 ? (
                            <div className="item303-util">
                                <div className={this.state.host_class_value} id="hosts">
                                </div>
                                <div className="item303-consumer">
                                    <div className="horizontal-scrollable">
                                        <div className="row" id="players">
                                            {/* <div className="col-xs-2"></div> */}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div className="item303-util-101" id="player"></div>
                        )}
                        <div className="item303-dump"></div>
                    </div>
                ) : null}
                {isMobile ? (
                    <div className="item305">
                        {this.state.streamsList.length > 1 ? (
                            <div className="item305-host" id="hosts"></div>
                        ) : null}
                        {this.state.streamsList.length > 1 ? (
                            <div className="item305-bar">
                                <RightBar
                                    isCameraOff={this.state.isCameraOff}
                                    meCameraOff={this.turnOffLocalCamera}
                                    meCameraOn={this.turnOnLocalCamera}
                                    isMicMuted={this.state.isMicMuted}
                                    meMicOff={this.muteLocalMic}
                                    meMicOn={this.unmuteLocalMic}
                                    room={this.state.roomName}
                                    socket={this.socket}
                                    cont_name={"user Name"}
                                    users={this.state.streamsList}
                                    // mobile users
                                    publicChatView={this.publicChatView}
                                    meNotesView={this.meNotesView}
                                    pollingView={this.pollingView}
                                    whiteboardView={this.whiteboardView}
                                    allUsersView={this.allUsersView}
                                    settingsViews={this.settingsViews}
                                    buttonStates={this.state}
                                />
                            </div>
                        ) : null}
                        {this.state.streamsList.length > 1 ? (
                            <div className="item305-consumers" id="players"></div>
                        ) : null}
                        {this.state.streamsList.length < 2 ? (
                            <div className="item303-util-101" id="player"></div>
                        ) : null}
                    </div>
                ) : null}
                {!isMobile ? (
                    <div className="item4">
                        <RightBar
                            isCameraOff={this.state.isCameraOff}
                            meCameraOff={this.turnOffLocalCamera}
                            meCameraOn={this.turnOnLocalCamera}
                            isMicMuted={this.state.isMicMuted}
                            meMicOff={this.muteLocalMic}
                            meMicOn={this.unmuteLocalMic}
                            room={this.state.roomName}
                            socket={this.socket}
                            cont_name={"user Name"}
                            users={this.state.streamsList}
                            // whiteBoardDisplay={this.whiteBoardDisplay}
                            // mobile users
                            publicChatView={this.publicChatView}
                            meNotesView={this.meNotesView}
                            pollingView={this.pollingView}
                            whiteboardView={this.whiteboardView}
                            settingsViews={this.settingsViews}
                            buttonStates={this.state}
                        />
                    </div>
                ) : null}
                {/* <div className="item5"></div> */}
                <div style={{ top: 'calc(100vh - 94vh)', width: "100%", position: 'absolute', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                    <button className="btn btn-info"
                        id="join_publish_button" onClick={this.joinRoom} disabled={this.state.join_publish_button}>Join Room</button>
                    <button className="btn btn-info" onClick={this.leaveRoom} disabled={this.state.stop_publish_button}
                        id="stop_publish_button">Leave Room</button>
                </div>
                {isMobile ? (
                    <div
                        onClick={() => {
                            this.setState({
                                meOptionsMobile: !this.state.meOptionsMobile
                            })
                        }}
                        className="me-stage"
                    >
                        <Me
                            isCameraOff={this.state.isCameraOff}
                            isMicMuted={this.state.isMicMuted}
                            cont_name={"user"}
                        />

                    </div>
                ) : null}
                {isMobile && this.state.meOptionsMobile ? (
                    <div className="me-mb-menu">
                        <div className="opt-head">
                            <span
                                className="close"
                                onClick={() => {
                                    this.setState({ meOptionsMobile: false })
                                }}
                            >&times;</span>
                        </div>
                        <div className="me-mb-opt-1">
                            <button className="me-btn-flip flip"></button>
                        </div>
                        <div className="me-mb-opt-2">
                            {this.state.isMicMuted ? (
                                <button onClick={this.unmuteLocalMic} className={`me-btn-mic mic-false`}></button>
                            ) : (
                                <button onClick={this.muteLocalMic} className={`me-btn-mic mic-true`}></button>
                            )}
                            {this.state.isCameraOff ? (
                                <button onClick={this.turnOnLocalCamera} className={`me-btn-video video-false`}></button>
                            ) : (
                                <button onClick={this.turnOffLocalCamera} className={`me-btn-video video-true`}></button>
                            )}
                        </div>
                    </div>
                ) : null}
                {/* mobile menu */}
                {this.state.headerOption ? (
                    <div style={{ boxShadow: "0px 2px 4px gray", display: "flex", flexDirection: "column", top: "1.8%", right: "3%", zIndex: 200, backgroundColor: '#fff', position: "absolute", width: 150, height: 80 }}>
                        <button onClick={() => {
                            this.settingsViews()
                            this.setState({
                                headerOption: !this.state.headerOption
                            })
                        }} className="menu-btn-header">Settings</button>
                        <button className="menu-btn-header">Exit</button>
                    </div>
                ) : null}
                {/* modals */}
                <div
                    id="myModal"
                    className={`modal modal-setting-${this.state.modalSetting}`}
                >
                    <div className="modal-content">
                        <div className="modal-container">
                            {isMobile ? (
                                <div className="modal-mobile-header">
                                    <button onClick={() => {
                                        this.settingsViews()
                                    }} className="btn-def-save">Done</button>
                                </div>
                            ) : null}
                            <div className="modal-left-box">
                                <div className="modal-setting-options">
                                    <button
                                        onClick={() => {
                                            this.setState({
                                                personalSetting: true,
                                                viewersSetting: false,
                                                active_set: "modal-btn-opt-active",
                                                active_View: ""

                                            })
                                        }}
                                        className={`modal-btn-opt ${this.state.active_set}`}
                                    >
                                        <span>Personal</span>
                                    </button>
                                    <button
                                        onClick={() => {
                                            this.setState({
                                                personalSetting: false,
                                                viewersSetting: true,
                                                active_View: "modal-btn-opt-active",
                                                active_set: ""
                                            })
                                        }}
                                        className={`modal-btn-opt ${this.state.active_View}`}
                                    >
                                        <span>Viewers</span>
                                    </button>
                                </div>
                            </div>
                            <div className="modal-right-box">
                                <div className="modal-headers">
                                    {this.state.personalSetting ? (
                                        <div className="modal-title">
                                            <span>Personal Settings</span>
                                        </div>
                                    ) : (
                                        <div className="modal-title">
                                            <div className="brand-h3">
                                                <span>Viewers Settings</span>
                                            </div>
                                            <div className="brand-hints">
                                                <span>
                                                    These options enable you to restric viewers from using specific features
                                                </span>
                                            </div>
                                        </div>
                                    )}
                                    <div className="modal-option">
                                        <span
                                            className="close"
                                            onClick={() => {
                                                this.setState({ modalSetting: false })
                                            }}
                                        >&times;</span>
                                    </div>
                                </div>
                                <div className="modal-data">
                                    {this.state.personalSetting ? (
                                        <div className="modal-data-box">
                                            <div className="event-options">
                                                <div className="opt-text">
                                                    <span>
                                                        Enable Animations
                                                    </span>
                                                </div>
                                                <div className="opt-toggle">
                                                    <div className="material-switch ">
                                                        <input
                                                            id="animations"
                                                            value={this.state.personal_Setting_obj.animations}
                                                            checked={this.state.personal_Setting_obj.animations === "on" ? true : false}
                                                            name="animations"
                                                            type="checkbox"
                                                            onChange={this.handlePersonalObj.bind(this)}
                                                        />
                                                        <label htmlFor="animations" className="label-primary"></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="event-options">
                                                <div className="opt-text">
                                                    <span>
                                                        Audio Alerts when any public or private message has been received
                                                    </span>
                                                </div>
                                                <div className="opt-toggle">
                                                    <div className="material-switch ">
                                                        <input
                                                            id="audioAlertsPublicPrivate"
                                                            name="audioAlertsPublicPrivate"
                                                            type="checkbox"
                                                            value={this.state.personal_Setting_obj.audioAlertsPublicPrivate}
                                                            checked={this.state.personal_Setting_obj.audioAlertsPublicPrivate === "on" ? true : false}
                                                            onChange={this.handlePersonalObj.bind(this)}
                                                        />
                                                        <label htmlFor="audioAlertsPublicPrivate" className="label-primary"></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="event-options">
                                                <div className="opt-text">
                                                    <span>
                                                        Popup Alerts when any public or private message has been received
                                                    </span>
                                                </div>
                                                <div className="opt-toggle">
                                                    <div className="material-switch ">
                                                        <input
                                                            id="popupAlertsPublicPrivate"
                                                            name="popupAlertsPublicPrivate"
                                                            type="checkbox"
                                                            value={this.state.personal_Setting_obj.popupAlertsPublicPrivate}
                                                            checked={this.state.personal_Setting_obj.popupAlertsPublicPrivate === "on" ? true : false}
                                                            onChange={this.handlePersonalObj.bind(this)}

                                                        />
                                                        <label htmlFor="popupAlertsPublicPrivate" className="label-primary"></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="event-options">
                                                <div className="opt-text">
                                                    <span>
                                                        Audio Alerts when any consumer has joined
                                                    </span>
                                                </div>
                                                <div className="opt-toggle">
                                                    <div className="material-switch ">
                                                        <input
                                                            id="audioAlertsNewConsumer"
                                                            name="audioAlertsNewConsumer"
                                                            type="checkbox"
                                                            value={this.state.personal_Setting_obj.audioAlertsNewConsumer}
                                                            checked={this.state.personal_Setting_obj.audioAlertsNewConsumer === "on" ? true : false}
                                                            onChange={this.handlePersonalObj.bind(this)}

                                                        />
                                                        <label htmlFor="audioAlertsNewConsumer" className="label-primary"></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="event-options">
                                                <div className="opt-text">
                                                    <span>
                                                        Popup Alerts when any consumer has joined
                                                    </span>
                                                </div>
                                                <div className="opt-toggle">
                                                    <div className="material-switch ">
                                                        <input
                                                            id="popupAlertsNewConsumer"
                                                            name="popupAlertsNewConsumer"
                                                            type="checkbox"
                                                            value={this.state.personal_Setting_obj.popupAlertsNewConsumer}
                                                            checked={this.state.personal_Setting_obj.popupAlertsNewConsumer === "on" ? true : false}
                                                            onChange={this.handlePersonalObj.bind(this)}
                                                        />
                                                        <label htmlFor="popupAlertsNewConsumer" className="label-primary"></label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="modal-data-box">
                                            <div className="event-options">
                                                <div className="opt-text">
                                                    <span>
                                                        Share webcam
                                                    </span>
                                                </div>
                                                <div className="opt-toggle">
                                                    <div className="material-switch ">
                                                        <input
                                                            id="shareWebcam"
                                                            name="shareWebcam"
                                                            type="checkbox"
                                                            value={this.state.viewers_Setting_obj.shareWebcam}
                                                            checked={this.state.viewers_Setting_obj.shareWebcam === "on" ? true : false}
                                                            onChange={this.handleViewersObj.bind(this)}

                                                        />
                                                        <label htmlFor="shareWebcam" className="label-primary"></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="event-options">
                                                <div className="opt-text">
                                                    <span>
                                                        See other viewers webcam
                                                    </span>
                                                </div>
                                                <div className="opt-toggle">
                                                    <div className="material-switch ">
                                                        <input
                                                            id="viewersWebcam"
                                                            name="viewersWebcam"
                                                            type="checkbox"
                                                            value={this.state.viewers_Setting_obj.viewersWebcam}
                                                            checked={this.state.viewers_Setting_obj.viewersWebcam === "on" ? true : false}
                                                            onChange={this.handleViewersObj.bind(this)}
                                                        />
                                                        <label htmlFor="viewersWebcam" className="label-primary"></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="event-options">
                                                <div className="opt-text">
                                                    <span>
                                                        Share microphone
                                                    </span>
                                                </div>
                                                <div className="opt-toggle">
                                                    <div className="material-switch ">
                                                        <input
                                                            id="shareMicrophone"
                                                            name="shareMicrophone"
                                                            type="checkbox"
                                                            value={this.state.viewers_Setting_obj.shareMicrophone}
                                                            checked={this.state.viewers_Setting_obj.shareMicrophone === "on" ? true : false}
                                                            onChange={this.handleViewersObj.bind(this)}

                                                        />
                                                        <label htmlFor="shareMicrophone" className="label-primary"></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="event-options">
                                                <div className="opt-text">
                                                    <span>
                                                        Send Public chat messages
                                                    </span>
                                                </div>
                                                <div className="opt-toggle">
                                                    <div className="material-switch ">
                                                        <input
                                                            id="publicChatMessage"
                                                            name="publicChatMessage"
                                                            type="checkbox"
                                                            value={this.state.viewers_Setting_obj.publicChatMessage}
                                                            checked={this.state.viewers_Setting_obj.publicChatMessage === "on" ? true : false}
                                                            onChange={this.handleViewersObj.bind(this)}

                                                        />
                                                        <label htmlFor="publicChatMessage" className="label-primary"></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="event-options">
                                                <div className="opt-text">
                                                    <span>
                                                        Send Private chat messages
                                                    </span>
                                                </div>
                                                <div className="opt-toggle">
                                                    <div className="material-switch ">
                                                        <input
                                                            id="privateChatMessage"
                                                            name="privateChatMessage"
                                                            type="checkbox"
                                                            value={this.state.viewers_Setting_obj.privateChatMessage}
                                                            checked={this.state.viewers_Setting_obj.privateChatMessage === "on" ? true : false}
                                                            onChange={this.handleViewersObj.bind(this)}

                                                        />
                                                        <label htmlFor="privateChatMessage" className="label-primary"></label>
                                                    </div>
                                                </div>
                                            </div>
                                            {/* <div className="event-options">
                                                <div className="opt-text">
                                                    <span>
                                                        Edit Shared Notes
                                                    </span>
                                                </div>
                                                <div className="opt-toggle">
                                                    <div className="material-switch ">
                                                        <input id="shared-notes" name="someSwitchOption001" type="checkbox" />
                                                        <label htmlhtmlFor="shared-notes" className="label-primary"></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="event-options">
                                                <div className="opt-text">
                                                    <span>
                                                        See other viewers in the Users list
                                                    </span>
                                                </div>
                                                <div className="opt-toggle">
                                                    <div className="material-switch ">
                                                        <input id="userslist" name="someSwitchOption001" type="checkbox" />
                                                        <label htmlhtmlFor="userslist" className="label-primary"></label>
                                                    </div>
                                                </div>
                                            </div> */}
                                        </div>
                                    )}
                                    <div className="modal-bottom">
                                        <button
                                            onClick={() => {
                                                this.setState({ modalSetting: false })
                                            }}
                                            className="brand-btn outline big"
                                        >
                                            <span>Cancel</span>
                                        </button>
                                        <button className="brand-btn fill big">
                                            <span>Save</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* all hidden modules */}
                {
                    this.state.users ? (
                        <Users
                            localData={"user Name"}
                            room={this.state.roomName}
                            socket={this.socket}
                            users={this.state.streamsList}
                            isCameraOff={this.state.isCameraOff}
                            isMicMuted={this.state.isMicMuted}
                            allUsersView={this.allUsersView}
                        />
                    ) : null
                }
                {
                    this.state.public_chat ? (
                        <PublicChatBoat
                            room={this.state.roomName}
                            socket={this.socket}
                            publicChatView={this.publicChatView}
                        />
                    ) : null
                }
                {
                    this.state.whiteboard ? (
                        <WhiteBoardComponent room={this.state.roomName} socket={this.socket} />
                    ) : null
                }
                {
                    this.state.notes ? (
                        <NotesForPublic
                            room={this.state.roomName}
                            socket={this.socket}
                            meNotesView={this.meNotesView}
                        />
                    ) : null
                }
                {
                    this.state.polling ? (
                        <PollingComponent
                            room={this.state.roomName}
                            socket={this.socket}
                            pollingView={this.pollingView}
                        />
                    ) : null
                }
            </div>
        )
    }
}