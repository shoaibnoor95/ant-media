import React from "react"
import './style.css'
// import Options from '../../assets/icons/icons-actions-overflow.svg'
import {
    // BrowserView,
    // MobileView,
    // isBrowser,
    isMobile
} from "react-device-detect";


class VeziuHeader extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            room: "connected",
            peers: [],
        }
    }

    render() {
        return (
            <div className='brand-header'>
                <div className='brand-logo' style={!isMobile ? { width: 'calc(100vw - 90vw)' } : { width: 'calc(100vw - 65vw)' }}></div>
                <div className='meeting-span' style={!isMobile ? { width: 'calc(100vw - 80vw)' } : { width: 'calc(100vw - 30vw)' }}>
                    <span>{"My meeting title"}</span>
                </div>
                <div className='brand-shape-h'></div>
                <div className='brand-dp' style={!isMobile ? { width: 'calc(100vw - 60vw)' } : { width: 'calc(100vw - 60vw)' }}>
                    <div className="meet-time" style={!isMobile ? { width: '25%' } : { width: '80%' }}>
                        <div className="time">
                            <span>{"60"}</span>
                        </div>
                        <div className="col">
                            <span>:</span>
                        </div>
                        <div className="time">
                            <span>{"60"}</span>
                        </div>
                        <div className="col">
                            <span>:</span>
                        </div>
                        <div className="time">
                            <span>{"60"}</span>
                        </div>
                    </div>
                    {!isMobile ? (
                        <div className="active-state">
                            <div className='online-indicator' style={this.props.isOnLine ? { backgroundColor: "green" } : { backgroundColor: "red" }} />
                            <div className="online-mess">
                                <span>{this.state.room === 'connected' ? "LIVE EVENT" : this.state.room}</span>
                            </div>
                        </div>
                    ) : null}
                    {!isMobile ? (
                        <div className="active-users">
                            <div className="user-q">
                                <span>{this.props.users.length > 0 ? this.props.users.length + 1 : '0'}</span>
                            </div>
                            <div className="col">
                                <span>:</span>
                            </div>
                            <div className="att-mess">
                                <span>ATTENDEES</span>
                            </div>
                        </div>
                    ) : null}
                </div>
                {isMobile ? (
                    <div className="res">
                        <button onClick={this.props.headerMenu} className="btn-opt menu"></button>
                    </div>
                ) : null}
                
            </div>
        )
    }
}

export default VeziuHeader;