// import PublicChatBoat from '../../component/public-chat'
// import WhiteBoardComponent from '../../component/white-board'
// import NotesForPublic from '../../component/notes'
// import PollingComponent from '../../component/polling'
import React from 'react'
import { connect } from 'react-redux';
// import Users from '../../component/users'
import './style.css'
import {
    // BrowserView,
    // MobileView,
    // isBrowser,
    isMobile
} from "react-device-detect";


class RightBar extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            micState: "on",
            webcamState: "on",
            grid: "off",
            users: isMobile ? false : true,
            public_chat: false,
            notes: false,
            polling: false,
            shareState: 'off',
            whiteboard: false,

        }
    }
    componentDidMount() {
        // if (!isMobile) {
        //     this.setState({
        //         users: true,
        //     })
        // }
    }


    render() {
        return (
            <div className='sidebar' >
                {!isMobile ? (
                    <div className="empty-box"></div>
                ) : null}
                {/* current user handles */}
                <div className='me-action'>
                    {this.props.isMicMuted ? (
                        <button onClick={this.props.meMicOn} className="me-btn" data-title="Mic">
                            <img src={'/assets/icons/icons-actions-mic-disable.svg'} alt="mic" />
                        </button>
                    ) : (
                        <button onClick={this.props.meMicOff} className="me-btn" data-title="Mic">
                            <img src={'/assets/icons/icons-actions-mic-enable.svg'} alt="mic" />
                        </button>
                    )}
                    {this.props.isCameraOff ? (
                        <button onClick={this.props.meCameraOn} className="me-btn" data-title="Video">
                            <img src={'/assets/icons/icons-actions-video-disable.svg'} alt="video" />
                        </button>
                    ) : (
                        <button onClick={this.props.meCameraOff} className="me-btn" data-title="Video">
                            <img src={'/assets/icons/icons-actions-video-enable.svg'} alt="video" />
                        </button>
                    )}
                </div>

                {/* modules */}
                <div className="brand-options">
                    {/* <button className={`me-opt-grid grid ${this.state.grid}`}
                        onClick={() => {

                        }}
                    ></button> */}
                    <button option-title="Users" className={`me-opt-users users-${this.props.buttonStates.users}`}
                        onClick={this.props.allUsersView}
                    ></button>
                    <button option-title="Public Chat" className={`me-opt-chat chat-${this.props.buttonStates.public_chat}`}
                        onClick={this.props.publicChatView}
                    ></button>
                    <button option-title="Notes" className={`me-opt-notes notes-${this.props.buttonStates.notes}`}
                        onClick={this.props.meNotesView}
                    ></button>
                    <button option-title="Polling" className={`me-opt-poll poll-${this.props.buttonStates.polling}`}
                        onClick={this.props.pollingView}
                    ></button>

                    {!isMobile ? (
                        <button
                            option-title="Screen Share"
                            className={`me-opt-shareScreen shareScreen-${this.props.buttonStates.shareState}`}
                            onClick={() => {
                                // if (shareState === 'on')
                                //     roomClient.disableShare();
                                // else
                                //     roomClient.enableShare();
                            }}
                        ></button>
                    ) : null}

                    {!isMobile ? (
                        <button
                            option-title="Whiteboard"
                            className={`me-opt-whiteboard whiteboard-${this.props.buttonStates.whiteboard}`}
                            onClick={this.props.whiteboardView}
                        ></button>
                    ) : null}
                </div>
                {/* settings and extra options */}
                {!isMobile ? (
                    <div className="brand-settings">
                        <button
                            className="me-setting setting"
                            onClick={this.props.settingsViews}
                        ></button>
                        <button className="me-end end-meeting"></button>
                    </div>
                ) : null}
            </div >
        )
    }
}
const mapStateToProps = () => {
    return {}
}

export default connect(mapStateToProps, null)(RightBar)