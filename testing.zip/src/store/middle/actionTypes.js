const actionTypes = {
    WEB_RTC_STATE: 'WEB_RTC_STATE',
    POOLING_JSON : "POOLING_JSON",
    PUBLIC_MESSAGES: 'PUBLIC_MESSAGES',
}

export default actionTypes