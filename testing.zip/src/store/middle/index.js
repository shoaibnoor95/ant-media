import actionTypes from './actionTypes'

export function webRtcDispatch(payload) {
    return {
        type: actionTypes.WEB_RTC_STATE,
        payload
    }
}


export function poolingDispatch(payload) {
    return {
        type: actionTypes.POOLING_JSON,
        payload
    }
}

export function publicMessageDispatch(payload) {
    return {
        type: actionTypes.PUBLIC_MESSAGES,
        payload
    }
}