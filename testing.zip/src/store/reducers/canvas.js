import actionTypes from '../middle/actionTypes';

const canvasWebRTC = (state = {
    webRTCData: [],
}, action) => {
    switch (action.type) {
        case actionTypes.WEB_RTC_STATE: {
            return state = {
                ...state,
                webRTCData: action.payload
            }
        }
        default: { }
    }
    return state;
}
export default canvasWebRTC;