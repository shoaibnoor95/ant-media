import React from 'react'
import './style.css'


class Peers extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            micState: "off",
            webcamState: "on"
        }
    }

    render() {

        let brand_peers = 'brand-Peers'
        let brand_peer = 'peer-container'
        if (this.props.streamsList.length <= 1) {
            brand_peers = 'brand-Peers-101'
            brand_peer = 'peer-container-101'
        }
        if (this.props.streamsList.length > 2 && this.props.streamsList.length <= 4) {
            brand_peers = 'brand-Peers-103'
            brand_peer = 'peer-container-103'
        }
        return (
            <div data-component={brand_peers} >
                <div className={brand_peer} >
                    <video id="remoteVideo" autoPlay muted playsInline></video>
                </div>
                <div className="bottom-st-bar">
                    <div className="st-bar" >
                        <div className='dp-name'>
                            <span>
                                {this.props.streamsList}
                            </span>
                        </div>
                        <div className='brand-shape'></div>
                        <div className='user-act' >
                            <button
                                className={[`dp-resp me-audio-${this.state.micState}`]}
                                disabled={true}
                            ></button>
                            <button
                                className={[`dp-resp me-video-${this.state.webcamState}`]}
                                disabled={true}
                            ></button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default Peers;