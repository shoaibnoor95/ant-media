import { createStore, combineReducers, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';

import PoolingRed from './reducers/pooling_reducers'

export default createStore(
    combineReducers({
        PoolingRed
    }),
    {},
    applyMiddleware(thunk)
);